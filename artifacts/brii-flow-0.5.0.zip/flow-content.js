"use strict";
(() => {
  // src/brii/decoding.ts
  var MAX_SEGMENT = 600;
  function sentenceStart(value, end) {
    const prefix = value.slice(0, end), trimmedEnd = prefix.trimEnd().length;
    let start = prefix.lastIndexOf("\n") + 1;
    for (const match of prefix.matchAll(/[.!?]["')\]]*\s+/g)) {
      const after = match.index + match[0].length;
      if (after <= trimmedEnd) start = Math.max(start, after);
    }
    return start;
  }
  function segmentAt(value, end, frontier, manual = false) {
    if (end < 0 || end > value.length || !manual && !/\s$/.test(value.slice(0, end))) return;
    let start = manual ? sentenceStart(value, end) : Math.min(frontier, end);
    while (start < end && /\s/.test(value[start])) start++;
    const raw = value.slice(start, end).trimEnd();
    if (!raw.trim()) return;
    if (raw.length > MAX_SEGMENT) throw Error(`Correction chunk exceeds ${MAX_SEGMENT} characters. Use shorter bursts or place the caret in a shorter sentence and use manual correction.`);
    return { start, end: start + raw.length, raw, context: value.slice(Math.max(0, start - 400), start), prefix: value.slice(0, start + raw.length) };
  }
  function planReplacement(segment, corrected, current, selection) {
    if (!current.startsWith(segment.prefix) || selection.start < segment.end || selection.end < segment.end) return;
    const delta = corrected.length - (segment.end - segment.start);
    return { start: segment.start, end: segment.end, text: corrected, delta, selection: { ...selection, start: selection.start + delta, end: selection.end + delta } };
  }

  // src/brii/flow.ts
  var BriiFlow = class {
    constructor(editor, options) {
      this.editor = editor;
      this.options = options;
      this.previous = editor.value;
      editor.addEventListener("beforeinput", () => {
        if (!this.applying && this.active()) this.before = { start: editor.selectionStart, end: editor.selectionEnd };
      });
      editor.addEventListener("input", (e) => this.input(e));
      editor.addEventListener("compositionstart", () => {
        this.composing = true;
        if (this.active()) this.invalidate("IME composition: correction paused.");
      });
      editor.addEventListener("compositionend", () => {
        this.composing = false;
        if (this.active()) this.previous = editor.value;
      });
      editor.addEventListener("keydown", (e) => {
        if (this.active() && (!this.options.trustedOnly || e.isTrusted) && (e.ctrlKey || e.metaKey) && e.key === "Enter" && !e.isComposing) {
          e.preventDefault();
          this.manual();
        }
      });
    }
    epoch = 0;
    frontier = 0;
    pending = false;
    applying = false;
    composing = false;
    previous;
    before;
    queued;
    timer;
    active() {
      return this.options.active?.() ?? true;
    }
    get isBusy() {
      return this.pending;
    }
    invalidate(message = "Pending corrections cancelled.") {
      this.epoch++;
      this.queued = void 0;
      clearTimeout(this.timer);
      if (this.active()) this.frontier = sentenceStart(this.editor.value, this.editor.selectionStart);
      else {
        this.frontier = 0;
        this.previous = "";
      }
      if (this.pending) this.options.cancel();
      this.options.status(message);
    }
    manual() {
      if (this.composing || !this.active()) return;
      this.editor.focus({ preventScroll: true });
      if (this.editor.selectionStart !== this.editor.selectionEnd) {
        this.options.status("Collapse the selection first. Selected text is never overwritten.");
        return;
      }
      this.enqueue(this.editor.selectionStart, true);
    }
    input(event) {
      if (this.applying || !this.active() || this.options.trustedOnly && !event.isTrusted) return;
      const value = this.editor.value;
      const history = event.inputType === "historyUndo" || event.inputType === "historyRedo";
      const appendOnly = this.before?.start === this.previous.length && this.before?.end === this.previous.length && value.startsWith(this.previous);
      this.before = void 0;
      if (history || !appendOnly) this.invalidate(history ? "Undo/redo preserved. Type another Space to resume." : "Edit invalidated the previous correction.");
      this.previous = value;
      if (this.composing || event.isComposing || history) return;
      if (this.options.automatic() && event.inputType === "insertText" && event.data === " " && this.editor.selectionStart === this.editor.selectionEnd) this.enqueue(this.editor.selectionStart, false);
    }
    enqueue(boundary, manual) {
      if (!this.options.ready()) {
        this.options.status("Decoder is not ready. Check the connection or model; raw typing continues normally.");
        return;
      }
      const at = performance.now();
      this.queued = { boundary, manual, epoch: this.epoch, due: at + (manual ? 0 : this.options.delay()), at };
      this.options.status(this.pending ? "Queued the latest completed text; current inference continues." : "Waiting for the short Space debounce\u2026");
      this.drain();
    }
    drain() {
      clearTimeout(this.timer);
      if (this.pending || !this.queued || this.composing) return;
      const wait = this.queued.due - performance.now();
      if (wait > 0) {
        this.timer = setTimeout(() => this.drain(), wait);
        return;
      }
      const queued = this.queued;
      this.queued = void 0;
      if (!this.options.ready() || queued.epoch !== this.epoch || !queued.manual && !this.options.automatic() || document.activeElement !== this.editor || this.editor.selectionStart < queued.boundary) {
        this.options.status("Queued correction skipped after focus, selection, model, or mode changed.");
        return;
      }
      let segment;
      try {
        segment = segmentAt(this.editor.value, queued.boundary, this.frontier, queued.manual);
      } catch (e) {
        this.options.status(String(e));
        return;
      }
      if (!segment) return;
      const started = queued.at;
      this.pending = true;
      this.options.status(this.options.decodingStatus || "Decoding locally\u2026 keep typing.");
      void this.options.decode(segment.raw, segment.context).then((result) => {
        let applied = false, unchanged = false, reason = result.validationError ? "Correction not applied: " + result.validationError : "Result discarded after an edit, selection change, blur, or composition.";
        if (this.active() && !result.validationError && queued.epoch === this.epoch && !this.composing && document.activeElement === this.editor) {
          const selection = { start: this.editor.selectionStart, end: this.editor.selectionEnd, direction: this.editor.selectionDirection };
          const plan = planReplacement(segment, result.corrected, this.editor.value, selection);
          if (plan) {
            if (segment.raw === result.corrected) {
              unchanged = true;
              reason = "The model returned the text unchanged. It may not have decoded it; the next completed words will be included in another attempt.";
            } else {
              const scrollTop = this.editor.scrollTop, scrollLeft = this.editor.scrollLeft;
              this.applying = true;
              try {
                this.editor.setSelectionRange(plan.start, plan.end);
                applied = document.execCommand("insertText", false, plan.text);
                if (applied) {
                  this.editor.setSelectionRange(plan.selection.start, plan.selection.end, plan.selection.direction);
                  reason = "Correction applied; ordinary Undo restores the raw text.";
                } else {
                  this.editor.setSelectionRange(selection.start, selection.end, selection.direction);
                  reason = "Browser rejected native insertion; original text preserved.";
                }
              } finally {
                this.applying = false;
                this.previous = this.editor.value;
                this.editor.scrollTop = scrollTop;
                this.editor.scrollLeft = scrollLeft;
              }
            }
            if (applied) {
              this.frontier = plan.start + plan.text.length;
              if (this.queued && this.queued.boundary >= plan.end) this.queued.boundary += plan.delta;
            }
          }
        }
        this.options.result({ segment, result, applied, unchanged, reason, elapsedMs: performance.now() - started });
        this.options.status(reason);
      }).catch((e) => this.options.status("Correction failed; original text preserved. " + String(e))).finally(() => {
        this.pending = false;
        this.drain();
        this.options.changed?.();
      });
    }
  };

  // src/brii/cloud-client.ts
  var CloudDecoder = class {
    constructor(send) {
      this.send = send;
    }
    current;
    async decode(text, context) {
      const requestId = crypto.randomUUID();
      this.current = requestId;
      const start = performance.now();
      try {
        const data = await this.send({ kind: "decode", requestId, text, context });
        if (data.error) throw Error(data.error);
        if (typeof data.corrected !== "string" || !data.corrected.trim() || data.corrected.length > 1800) throw Error("Invalid cloud correction; original text was preserved.");
        return { corrected: data.corrected, rawOutput: data.corrected, ttftMs: null, totalMs: performance.now() - start, finishReason: "complete" };
      } finally {
        if (this.current === requestId) this.current = void 0;
      }
    }
    cancel() {
      if (this.current) void this.send({ kind: "cancel", requestId: this.current }).catch(() => {
      });
    }
  };
  var extensionTransport = (message) => chrome.runtime.sendMessage({ target: "briiCloud", ...message });

  // src/brii/cloud.ts
  var cloudDefaults = { enabled: false, automatic: true, sites: [], delay: 80 };
  var cloudSettings = async () => ({ ...cloudDefaults, ...(await chrome.storage.local.get("briiCloud")).briiCloud || {} });
  function cloudAllowed(url, s) {
    try {
      return s.enabled && s.sites.includes(new URL(url).origin);
    } catch {
      return false;
    }
  }

  // src/shared.ts
  function safeField(el) {
    if (!(el instanceof HTMLTextAreaElement || el instanceof HTMLInputElement)) return false;
    if (el instanceof HTMLInputElement && !["text", "search"].includes(el.type)) return false;
    return !el.disabled && !el.readOnly && !el.closest("[data-private]") && !/password|one-time|cc-|username|email|tel|address|name|birth|transaction|ssn|social.?security|credit.?card|card.?number|cvv|bank|routing|api.?key|secret|token|otp/i.test(el.autocomplete + " " + el.getAttribute("name") + " " + el.id + " " + el.getAttribute("aria-label"));
  }

  // src/flow-content.ts
  var global = globalThis;
  if (!global.__briiFlow) {
    let show = function(message) {
      if (!active()) {
        host.remove();
        return;
      }
      if (!host.isConnected) document.documentElement.append(host);
      status.textContent = "Brii \xB7 OpenAI \xB7 " + message;
    }, attach = function(element) {
      if (!active() || !safeField(element) || known.has(element)) return;
      for (const item of flows) if (!item.element.isConnected) {
        item.flow.invalidate();
        flows.delete(item);
      }
      known.add(element);
      const decoder = new CloudDecoder(extensionTransport);
      const flow = new BriiFlow(element, { active: () => active() && safeField(element), trustedOnly: true, ready: active, automatic: () => !!config?.automatic, delay: () => config?.delay || 80, decodingStatus: "Decoding with OpenAI\u2026 keep typing.", decode: (text, context) => decoder.decode(text, context), cancel: () => decoder.cancel(), status: show, result: (r) => {
        if (r.applied) show(`Corrected \xB7 ${Math.round(r.result.totalMs)} ms \xB7 Undo to restore`);
      } });
      flows.add({ element, flow });
    };
    show2 = show, attach2 = attach;
    global.__briiFlow = true;
    let config;
    const flows = /* @__PURE__ */ new Set();
    const known = /* @__PURE__ */ new WeakSet();
    const host = document.createElement("div");
    host.style.cssText = "position:fixed;right:12px;bottom:12px;z-index:2147483647;pointer-events:none;";
    const shadow = host.attachShadow({ mode: "closed" });
    const status = document.createElement("div");
    status.style.cssText = "font:12px/1.5 system-ui;background:#173a2b;color:white;padding:7px 12px;border-radius:5px;max-width:400px;";
    status.setAttribute("role", "status");
    shadow.append(status);
    const active = () => !!config && cloudAllowed(location.href, config);
    document.addEventListener("focusin", (event) => {
      if (event.isTrusted) attach(event.target);
    }, true);
    void cloudSettings().then((s) => {
      config = s;
      attach(document.activeElement);
    });
    chrome.storage.onChanged.addListener((c, a) => {
      if (a === "local" && c.briiCloud) {
        config = c.briiCloud.newValue;
        for (const item of flows) item.flow.invalidate("Cloud correction settings changed.");
        if (!active()) host.remove();
        else attach(document.activeElement);
      }
    });
  }
  var show2;
  var attach2;
})();
