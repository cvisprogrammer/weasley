"use strict";
(() => {
  // src/context.ts
  var CONTEXT_LIMIT = 1200;
  function normalizeContext(text) {
    return text.replace(/\s+/g, " ").trim().slice(0, CONTEXT_LIMIT);
  }
  var excluded = 'input,textarea,select,option,button,label,[contenteditable]:not([contenteditable="false"]),[data-private],[data-weasley-ui],script,style,noscript,nav,header,footer,aside,[role="navigation"],[role="menu"],[aria-hidden="true"],[hidden]';
  var stopwords = new Set("a an the and or but to of in on at for is are was were be this that it i we you our your with from have has will can".split(" "));
  var terms = (text) => new Set((text.toLowerCase().match(/[\p{L}\p{N}]{3,}/gu) || []).filter((w) => !stopwords.has(w)));
  function harvestContext(field2, draft) {
    const roots = [];
    let anchor = field2;
    for (let depth = 0; anchor && depth < 3; depth++, anchor = anchor.parentElement) {
      let sibling = anchor.previousElementSibling;
      for (let n = 0; sibling && n < 3; n++, sibling = sibling.previousElementSibling) roots.push(sibling);
    }
    const semantic = field2.closest('article,main,[role="main"]') || document.querySelector('main,[role="main"],article');
    if (field2.parentElement) roots.push(field2.parentElement);
    if (semantic) roots.push(semantic);
    if (document.body) roots.push(document.body);
    const visited = /* @__PURE__ */ new Set(), groups = /* @__PURE__ */ new Map();
    const query = terms(draft.slice(-500)), deadline = performance.now() + 10;
    let scanned = 0;
    function visit(node) {
      if (visited.has(node)) return;
      visited.add(node);
      const parent = node.parentElement;
      if (!parent || parent.closest(excluded)) return;
      if (!parent.checkVisibility({ checkOpacity: true, checkVisibilityCSS: true })) return;
      const text = (node.textContent || "").slice(0, 600).replace(/\s+/g, " ").trim();
      if (text.length < 8) return;
      const block = parent.closest("p,li,blockquote,h1,h2,h3,div,section,article") || parent;
      if (!block.getClientRects().length) return;
      const style = getComputedStyle(block);
      if (style.visibility === "hidden" || style.display === "none") return;
      const existing = groups.get(block);
      if (existing) {
        existing.text = (existing.text + " " + text).slice(0, 600);
        return;
      }
      const overlap = [...terms(text)].filter((w) => query.has(w)).length;
      const preceding = !!(block.compareDocumentPosition(field2) & Node.DOCUMENT_POSITION_FOLLOWING);
      const close = field2.parentElement?.contains(block) ? 4 : 0;
      groups.set(block, { text: text.slice(0, 600), score: overlap * 3 + (preceding ? 3 : 0) + close, order: groups.size });
    }
    outer: for (const root of roots) {
      if (root instanceof Element && root.closest(excluded)) continue;
      const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
      let node;
      while (node = walker.nextNode()) {
        if (++scanned > 1e3 || performance.now() > deadline) break outer;
        visit(node);
      }
    }
    const seen = /* @__PURE__ */ new Set();
    const ranked = [...groups.values()].sort((a, b) => b.score - a.score || a.order - b.order).filter((x) => {
      if (seen.has(x.text)) return false;
      seen.add(x.text);
      return true;
    });
    return normalizeContext(ranked.slice(0, 6).map((x) => x.text).join(" "));
  }

  // src/shared.ts
  var modelId = "Qwen3.5-2B-q4f16_1-MLC";
  var defaults = { enabled: true, model: modelId, sites: [], delay: 250, maxWords: 3 };
  var settings = async () => ({ ...defaults, ...(await chrome.storage.local.get("settings")).settings || {} });
  function allowed(url, s) {
    try {
      return s.enabled && s.sites.includes(new URL(url).origin);
    } catch {
      return false;
    }
  }
  function nextWord(text) {
    return text.match(/^\s*\S+\s*/)?.[0] || text;
  }
  function safeField(el) {
    if (!(el instanceof HTMLTextAreaElement || el instanceof HTMLInputElement)) return false;
    if (el instanceof HTMLInputElement && !["text", "search"].includes(el.type)) return false;
    return !el.disabled && !el.readOnly && !el.closest("[data-private]") && !/password|one-time|cc-|username|email|tel|address|name|birth|transaction|ssn|social.?security|credit.?card|card.?number|cvv|bank|routing|api.?key|secret|token|otp/i.test(el.autocomplete + " " + el.getAttribute("name") + " " + el.id + " " + el.getAttribute("aria-label"));
  }

  // src/content.ts
  var context = "";
  var contextUrl = location.href;
  var contextField = null;
  var contextAt = 0;
  var lastStatus = "Ready to type";
  function status(text) {
    lastStatus = text;
    const node = document.querySelector("[data-weasley-status]");
    if (node) node.textContent = text;
  }
  var labPage = location.href === chrome.runtime.getURL("test.html");
  var ownTabId;
  if (labPage) void chrome.tabs.getCurrent().then((tab) => ownTabId = tab?.id);
  var canUsePage = (s) => allowed(location.href, s) || s.enabled && labPage;
  var config;
  var composing = false;
  var epoch = 0;
  var suggestion = "";
  var snapshot = "";
  var cursor = 0;
  var pending = false;
  var field = null;
  var timer;
  var host = document.createElement("div");
  host.setAttribute("data-weasley-ui", "");
  host.style.cssText = "position:fixed;inset:0;pointer-events:none;z-index:2147483647";
  var shadow = host.attachShadow({ mode: "closed" });
  var ghost = document.createElement("div");
  shadow.append(ghost);
  ghost.setAttribute("aria-hidden", "true");
  var send = (kind, data = {}) => chrome.runtime.sendMessage({ target: "background", kind, ...data }).catch(() => ({ text: "", error: "Extension connection lost. Reload this page and check Weasley." }));
  var metric = (event, data = {}) => void send("metric", { event, ...data });
  function clear(reject = true) {
    clearTimeout(timer);
    epoch++;
    if (suggestion && reject) metric("rejected");
    suggestion = "";
    ghost.textContent = "";
    if (pending) {
      pending = false;
      void send("cancel");
    }
  }
  function paint() {
    if (!field || !suggestion) return;
    if (!host.isConnected) document.documentElement.append(host);
    const r = field.getBoundingClientRect(), s = getComputedStyle(field), mirror = document.createElement("div");
    for (const p2 of ["font", "letterSpacing", "lineHeight", "padding", "border", "boxSizing", "textIndent", "wordSpacing"]) mirror.style[p2] = s[p2];
    mirror.style.cssText += `;position:fixed;visibility:hidden;left:${r.left}px;top:${r.top}px;width:${r.width}px;white-space:${field instanceof HTMLTextAreaElement ? "pre-wrap" : "pre"};overflow-wrap:break-word;`;
    mirror.textContent = field.value.slice(0, cursor);
    const marker = document.createElement("span");
    marker.textContent = "\u200B";
    mirror.append(marker);
    shadow.append(mirror);
    const p = marker.getBoundingClientRect();
    mirror.remove();
    const x = p.left - field.scrollLeft, y = p.top - field.scrollTop;
    if (x < r.left || x > r.right - 8 || y < r.top || y > r.bottom - 8) {
      ghost.textContent = "";
      return;
    }
    ghost.style.cssText = `position:fixed;left:${x}px;top:${y}px;font:${s.font};letter-spacing:${s.letterSpacing};color:${s.color};opacity:.45;white-space:pre;max-width:${r.right - x - 8}px;overflow:hidden;`;
    ghost.textContent = suggestion;
  }
  async function schedule() {
    if (contextUrl !== location.href) {
      context = "";
      contextField = null;
      contextAt = 0;
      contextUrl = location.href;
    }
    clear();
    if (!config) return;
    if (!canUsePage(config)) {
      status("Enable Weasley and allow this website in the popup, then reload this page.");
      return;
    }
    if (composing || !safeField(document.activeElement)) return;
    field = document.activeElement;
    if (field.selectionStart !== field.selectionEnd || field.selectionStart !== field.value.length) {
      status("Move the caret to the end of your message to get a suggestion.");
      return;
    }
    if (field.value.trim().length < 3) {
      status("Type a few words. Page context is picked up automatically.");
      return;
    }
    snapshot = field.value;
    cursor = field.selectionStart;
    const ticket = epoch, target = field;
    status("Waiting for a pause\u2026");
    let attempts = 0;
    const valid = () => ticket === epoch && !composing && document.activeElement === target && target.value === snapshot && target.selectionStart === cursor && config.enabled;
    const run = async () => {
      if (!valid()) return;
      if (contextField !== target || performance.now() - contextAt > 3e3) {
        context = harvestContext(target, snapshot);
        contextField = target;
        contextAt = performance.now();
      }
      status("Predicting\u2026");
      pending = true;
      let timeout;
      const r = await Promise.race([send("predict", { prefix: snapshot.slice(-1800), context }), new Promise((resolve) => {
        timeout = setTimeout(() => resolve({ text: "", error: "Prediction timed out. Use Release GPU / reset engine in Weasley, then load again." }), 3e4);
      })]);
      clearTimeout(timeout);
      if (ticket === epoch) pending = false;
      if (!valid()) return;
      if (r.reason === "busy" && attempts++ < 30) {
        status("Model is finishing the previous prediction\u2026");
        timer = setTimeout(() => void run(), 150);
        return;
      }
      if (r.text) {
        suggestion = r.text;
        paint();
        status("Tab to accept \xB7 Alt+Right for one word \xB7 Escape to dismiss");
        metric("shown", { chars: suggestion.length, ttft: r.ttft, total: r.total });
      } else status(r.error || r.reason || "No continuation returned. Keep typing.");
    };
    timer = setTimeout(() => void run(), config.delay);
  }
  document.addEventListener("focusin", () => void schedule(), true);
  document.addEventListener("input", () => void schedule(), true);
  document.addEventListener("compositionstart", () => {
    composing = true;
    clear();
  }, true);
  document.addEventListener("compositionend", () => {
    composing = false;
    void schedule();
  }, true);
  for (const event of ["focusout", "pointerdown", "scroll"]) document.addEventListener(event, () => clear(), true);
  window.addEventListener("resize", () => clear());
  document.addEventListener("keydown", (e) => {
    if (composing || e.isComposing) return;
    if (e.key === "Escape") {
      clear();
      status("Suggestion dismissed. Keep typing.");
      return;
    }
    if (suggestion && field && document.activeElement === field && field.value === snapshot && field.selectionStart === cursor && field.selectionEnd === cursor && (e.key === "Tab" && !e.shiftKey && !e.ctrlKey && !e.altKey && !e.metaKey || e.key === "ArrowRight" && e.altKey && !e.shiftKey && !e.ctrlKey && !e.metaKey)) {
      const text = e.altKey ? nextWord(suggestion) : suggestion;
      e.preventDefault();
      e.stopImmediatePropagation();
      clear(false);
      if (document.execCommand("insertText", false, text)) {
        metric("accepted", { chars: text.length, keys: e.altKey ? 2 : 1 });
        void schedule();
      }
      return;
    }
    if (!["Shift", "Control", "Alt", "Meta"].includes(e.key)) clear();
  }, true);
  void settings().then((s) => {
    config = s;
    status(canUsePage(s) ? "Ready. Type in the field; page context is automatic." : "Allow this website in Weasley, load the model, and reload this page.");
  });
  chrome.storage.onChanged.addListener((c, a) => {
    if (a === "local" && c.settings) {
      config = c.settings.newValue;
      if (!canUsePage(config)) {
        context = "";
        contextField = null;
        contextAt = 0;
      }
      clear();
    }
  });
  chrome.runtime.onMessage.addListener((m, sender, reply) => {
    if (sender.id !== chrome.runtime.id || sender.tab || sender.url !== chrome.runtime.getURL("popup.html") || m.kind !== "contextStatus") return;
    if (m.target === "lab" && (!labPage || m.labTabId !== ownTabId)) return;
    if (!config || !canUsePage(config)) {
      reply({ error: "Enable and allow this website first." });
      return;
    }
    if (contextUrl !== location.href) {
      context = "";
      contextField = null;
      contextAt = 0;
      contextUrl = location.href;
    }
    reply({ context, characters: context.length, status: lastStatus });
  });
})();
