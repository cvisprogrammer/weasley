// src/brii/decoding.ts
var MAX_SEGMENT = 600;
function sentenceStart(value, end) {
  const prefix = value.slice(0, end), trimmedEnd = prefix.trimEnd().length;
  let start = prefix.lastIndexOf("\n") + 1;
  for (const match of prefix.matchAll(/[.!?]["')\]]*\s+/g)) {
    const after = match.index + match[0].length;
    if (after <= trimmedEnd) start = Math.max(start, after);
  }
  return start;
}
function segmentAt(value, end, frontier, manual = false) {
  if (end < 0 || end > value.length || !manual && !/\s$/.test(value.slice(0, end))) return;
  let start = manual ? sentenceStart(value, end) : Math.min(frontier, end);
  while (start < end && /\s/.test(value[start])) start++;
  const raw = value.slice(start, end).trimEnd();
  if (!raw.trim()) return;
  if (raw.length > MAX_SEGMENT) throw Error(`Correction chunk exceeds ${MAX_SEGMENT} characters. Use shorter bursts or place the caret in a shorter sentence and use manual correction.`);
  return { start, end: start + raw.length, raw, context: value.slice(Math.max(0, start - 400), start), prefix: value.slice(0, start + raw.length) };
}
function planReplacement(segment, corrected, current, selection) {
  if (!current.startsWith(segment.prefix) || selection.start < segment.end || selection.end < segment.end) return;
  const delta = corrected.length - (segment.end - segment.start);
  return { start: segment.start, end: segment.end, text: corrected, delta, selection: { ...selection, start: selection.start + delta, end: selection.end + delta } };
}

// src/brii/rolling.ts
function rawBoundaries(raw, text) {
  const width = text.length + 1, table = new Uint16Array((raw.length + 1) * width);
  for (let i2 = 0; i2 <= raw.length; i2++) table[i2 * width] = i2;
  for (let j2 = 0; j2 <= text.length; j2++) table[j2] = j2;
  for (let i2 = 1; i2 <= raw.length; i2++) for (let j2 = 1; j2 <= text.length; j2++) table[i2 * width + j2] = Math.min(table[(i2 - 1) * width + j2] + 1, table[i2 * width + j2 - 1] + 1, table[(i2 - 1) * width + j2 - 1] + (raw[i2 - 1] === text[j2 - 1] ? 0 : 1));
  const boundary = new Array(width);
  let i = raw.length, j = text.length;
  boundary[j] = i;
  while (i || j) {
    const cost = table[i * width + j];
    if (i && j && cost === table[(i - 1) * width + j - 1] + (raw[i - 1] === text[j - 1] ? 0 : 1)) {
      i--;
      j--;
      boundary[j] = i;
    } else if (i && cost === table[(i - 1) * width + j] + 1) {
      i--;
      boundary[j] = i;
    } else {
      j--;
      boundary[j] = i;
    }
  }
  boundary[0] = 0;
  boundary[text.length] = raw.length;
  return boundary;
}
var RollingDraft = class {
  revisions = [];
  protectedEnd = 0;
  protect(end) {
    this.revisions = [];
    this.protectedEnd = end;
  }
  segment(value, boundary, wholeSentence = false, manual = false) {
    let start = Math.max(manual ? 0 : this.protectedEnd, sentenceStart(value, boundary));
    const end = value.slice(0, boundary).trimEnd().length;
    if (end <= start) return;
    if (!wholeSentence) {
      const words = [...value.slice(start, end).matchAll(/\S+/g)];
      if (words.length > 12) start += words[words.length - 12].index;
    }
    for (const revision of this.revisions) if (revision.start < start && revision.end > start) start = revision.start;
    while (start < end && /\s/.test(value[start])) start++;
    const shown = value.slice(start, end);
    if (!shown.trim()) return;
    let raw = "", at = start;
    for (const revision of this.revisions) {
      if (revision.start < start || revision.end > end) continue;
      raw += value.slice(at, revision.start) + revision.raw;
      at = revision.end;
    }
    raw += value.slice(at, end);
    if (raw.length > MAX_SEGMENT || shown.length > MAX_SEGMENT) throw Error(`Correction chunk exceeds ${MAX_SEGMENT} characters. Finish this sentence before continuing.`);
    return { start, end, raw, context: value.slice(Math.max(0, start - 400), start), prefix: value.slice(0, end) };
  }
  applied(segment, text) {
    const delta = text.length - (segment.end - segment.start);
    if (segment.start < this.protectedEnd) this.protectedEnd = Math.max(segment.start, this.protectedEnd + delta);
    this.revisions = this.revisions.filter((r) => r.end <= segment.start || r.start >= segment.end).map((r) => r.start >= segment.end ? { ...r, start: r.start + delta, end: r.end + delta } : r);
    const boundaries = rawBoundaries(segment.raw, text);
    for (const word of text.matchAll(/\S+|\s+/g)) {
      const start = word.index, end = start + word[0].length;
      this.revisions.push({ start: segment.start + start, end: segment.start + end, raw: segment.raw.slice(boundaries[start], boundaries[end]) });
    }
    this.revisions.sort((a, b) => a.start - b.start);
  }
};

// src/brii/flow.ts
var BriiFlow = class {
  constructor(editor, options) {
    this.editor = editor;
    this.options = options;
    this.previous = editor.value;
    editor.addEventListener("beforeinput", () => {
      if (!this.applying && this.active()) this.before = { start: editor.selectionStart, end: editor.selectionEnd };
    });
    editor.addEventListener("input", (e) => this.input(e));
    editor.addEventListener("compositionstart", () => {
      this.composing = true;
      if (this.active()) this.invalidate("IME composition: correction paused.");
    });
    editor.addEventListener("compositionend", () => {
      this.composing = false;
      if (this.active()) this.previous = editor.value;
    });
    editor.addEventListener("keydown", (e) => {
      if (this.active() && (!this.options.trustedOnly || e.isTrusted) && (e.ctrlKey || e.metaKey) && e.key === "Enter" && !e.isComposing) {
        e.preventDefault();
        this.manual();
      }
    });
  }
  draft = new RollingDraft();
  pauseTimer;
  epoch = 0;
  frontier = 0;
  pending = false;
  applying = false;
  composing = false;
  previous;
  before;
  queued;
  timer;
  active() {
    return this.options.active?.() ?? true;
  }
  get isBusy() {
    return this.pending;
  }
  invalidate(message = "Pending corrections cancelled.") {
    clearTimeout(this.pauseTimer);
    this.epoch++;
    this.queued = void 0;
    clearTimeout(this.timer);
    if (this.active()) {
      this.frontier = sentenceStart(this.editor.value, this.editor.selectionStart);
      this.previous = this.editor.value;
    } else {
      this.frontier = 0;
      this.previous = "";
      this.draft.protect(0);
    }
    if (this.pending) this.options.cancel();
    this.options.status(message);
  }
  manual() {
    if (this.composing || !this.active()) return;
    this.editor.focus({ preventScroll: true });
    if (this.editor.selectionStart !== this.editor.selectionEnd) {
      this.options.status("Collapse the selection first. Selected text is never overwritten.");
      return;
    }
    this.enqueue(this.editor.selectionStart, true);
  }
  input(event) {
    if (this.applying || !this.active() || this.options.trustedOnly && !event.isTrusted) return;
    const value = this.editor.value;
    clearTimeout(this.pauseTimer);
    const history = event.inputType === "historyUndo" || event.inputType === "historyRedo";
    const appendOnly = this.before?.start === this.previous.length && this.before?.end === this.previous.length && value.startsWith(this.previous);
    this.before = void 0;
    if (history || !appendOnly) this.invalidate(history ? "Undo/redo preserved. Type another Space to resume." : "Edit invalidated the previous correction.");
    if (this.options.rolling && (history || !appendOnly)) this.draft.protect(value.length);
    this.previous = value;
    if (this.composing || event.isComposing || history) return;
    if (this.options.automatic() && event.inputType === "insertText" && event.data === " " && this.editor.selectionStart === this.editor.selectionEnd) this.enqueue(this.editor.selectionStart, false);
    if (this.options.rolling && this.options.automatic() && event.inputType === "insertText" && appendOnly) {
      const epoch = this.epoch;
      this.pauseTimer = setTimeout(() => {
        if (epoch !== this.epoch || !this.active() || !this.options.automatic() || this.editor.selectionStart !== this.editor.value.length || this.editor.selectionEnd !== this.editor.value.length) return;
        const boundary = this.editor.value.length, prefix = this.editor.value;
        const completed = /[.!?]$/.test(prefix) ? boundary : prefix.search(/\S*$/);
        if (completed > 0) this.enqueue(completed, false, true);
      }, 650);
    }
  }
  enqueue(boundary, manual, wholeSentence = false) {
    if (!this.options.ready()) {
      this.options.status("Decoder is not ready. Check the connection or model; raw typing continues normally.");
      return;
    }
    const at = performance.now();
    this.queued = { boundary, manual, wholeSentence, epoch: this.epoch, due: at + (manual ? 0 : this.options.delay()), at };
    this.options.status(this.pending ? "Queued the latest completed text; current inference continues." : "Waiting for the short Space debounce\u2026");
    this.drain();
  }
  drain() {
    clearTimeout(this.timer);
    if (this.pending || !this.queued || this.composing) return;
    const wait = this.queued.due - performance.now();
    if (wait > 0) {
      this.timer = setTimeout(() => this.drain(), wait);
      return;
    }
    const queued = this.queued;
    this.queued = void 0;
    if (!this.options.ready() || queued.epoch !== this.epoch || !queued.manual && !this.options.automatic() || document.activeElement !== this.editor || this.editor.selectionStart < queued.boundary) {
      this.options.status("Queued correction skipped after focus, selection, model, or mode changed.");
      return;
    }
    let segment;
    try {
      segment = this.options.rolling ? this.draft.segment(this.editor.value, queued.boundary, queued.wholeSentence || queued.manual, queued.manual) : segmentAt(this.editor.value, queued.boundary, this.frontier, queued.manual);
    } catch (e) {
      this.options.status(String(e));
      return;
    }
    if (!segment) return;
    const started = queued.at;
    this.pending = true;
    this.options.status(this.options.decodingStatus || "Decoding locally\u2026 keep typing.");
    void this.options.decode(segment.raw, segment.context).then((result) => {
      let applied = false, unchanged = false, reason = result.validationError ? "Correction not applied: " + result.validationError : "Result discarded after an edit, selection change, blur, or composition.";
      if (this.active() && !result.validationError && queued.epoch === this.epoch && !this.composing && document.activeElement === this.editor) {
        const selection = { start: this.editor.selectionStart, end: this.editor.selectionEnd, direction: this.editor.selectionDirection };
        const plan = planReplacement(segment, result.corrected, this.editor.value, selection);
        if (plan) {
          if (this.editor.value.slice(segment.start, segment.end) === result.corrected) {
            unchanged = true;
            reason = "The model returned the text unchanged. It may not have decoded it; the next completed words will be included in another attempt.";
          } else {
            const scrollTop = this.editor.scrollTop, scrollLeft = this.editor.scrollLeft;
            this.applying = true;
            try {
              this.editor.setSelectionRange(plan.start, plan.end);
              applied = document.execCommand("insertText", false, plan.text);
              if (applied) {
                this.editor.setSelectionRange(plan.selection.start, plan.selection.end, plan.selection.direction);
                reason = "Correction applied; ordinary Undo restores the raw text.";
              } else {
                this.editor.setSelectionRange(selection.start, selection.end, selection.direction);
                reason = "Browser rejected native insertion; original text preserved.";
              }
            } finally {
              this.applying = false;
              this.previous = this.editor.value;
              this.editor.scrollTop = scrollTop;
              this.editor.scrollLeft = scrollLeft;
            }
          }
          if (applied) {
            if (this.options.rolling) this.draft.applied(segment, plan.text);
            this.frontier = plan.start + plan.text.length;
            if (this.queued && this.queued.boundary >= plan.end) this.queued.boundary += plan.delta;
          }
        }
      }
      this.options.result({ segment, result, applied, unchanged, reason, elapsedMs: performance.now() - started });
      this.options.status(reason);
    }).catch((e) => this.options.status("Correction failed; original text preserved. " + String(e))).finally(() => {
      this.pending = false;
      this.drain();
      this.options.changed?.();
    });
  }
};

// src/brii/cloud-client.ts
var CloudDecoder = class {
  constructor(send2) {
    this.send = send2;
  }
  current;
  async decode(text, context) {
    const requestId = crypto.randomUUID();
    this.current = requestId;
    const start = performance.now();
    try {
      const data = await this.send({ kind: "decode", requestId, text, context });
      if (data.error) throw Error(data.error);
      if (typeof data.corrected !== "string" || !data.corrected.trim() || data.corrected.length > 1800) throw Error("Invalid cloud correction; original text was preserved.");
      return { corrected: data.corrected, rawOutput: data.corrected, ttftMs: null, totalMs: performance.now() - start, finishReason: "complete" };
    } finally {
      if (this.current === requestId) this.current = void 0;
    }
  }
  cancel() {
    if (this.current) void this.send({ kind: "cancel", requestId: this.current }).catch(() => {
    });
  }
};
var extensionTransport = (message) => chrome.runtime.sendMessage({ target: "briiCloud", ...message });

// src/brii/cloud.ts
var cloudDefaults = { enabled: false, automatic: true, sites: [], delay: 80 };
var cloudSettings = async () => ({ ...cloudDefaults, ...(await chrome.storage.local.get("briiCloud")).briiCloud || {} });

// src/cloud-playground.ts
var $ = (id) => document.getElementById(id);
var consent = $("consent");
var auto = $("auto");
var correct = $("correct");
var extension = location.protocol === "chrome-extension:";
var configured = false;
var extensionId = "";
var localAbort;
var send = extension ? extensionTransport : async (message) => {
  if (message.kind === "cancel") {
    localAbort?.abort();
    return { ok: true };
  }
  const path = message.kind === "health" ? "/health" : "/correct";
  localAbort = new AbortController();
  const response = await fetch(path, { method: message.kind === "health" ? "GET" : "POST", headers: { "Content-Type": "application/json", "X-Brii-Extension": extensionId }, ...message.kind === "decode" ? { body: JSON.stringify({ text: message.text, context: message.context }) } : {}, signal: localAbort.signal, cache: "no-store" });
  const data = await response.json();
  return response.ok ? data : { error: data.error || "Bridge request failed." };
};
var decoder = new CloudDecoder(send);
var flow = new BriiFlow($("editor"), { rolling: true, active: () => consent.checked, ready: () => consent.checked && configured, automatic: () => auto.checked, delay: () => 80, decodingStatus: "Decoding with OpenAI\u2026 keep typing.", decode: (text, context) => decoder.decode(text, context), cancel: () => decoder.cancel(), status: (text) => {
  $("status").textContent = text;
}, result: (r) => {
  if (r.applied) $("status").textContent = `Corrected \xB7 ${Math.round(r.result.totalMs)} ms round trip \xB7 Undo to restore`;
} });
async function health() {
  try {
    const h = await send({ kind: "health" });
    configured = !!h.enabled && !h.error;
    extensionId = h.extensionId || "";
    $("bridgeStatus").textContent = h.error || (configured ? `Ready \xB7 ${h.model} \xB7 cloud` : "Set OPENAI_API_KEY in the bridge terminal and restart it.");
  } catch {
    $("bridgeStatus").textContent = "Start npm run cloud on this machine.";
  }
  correct.disabled = !configured || !consent.checked;
}
if (extension) void cloudSettings().then((s) => {
  consent.checked = s.enabled;
  auto.checked = s.automatic;
  void health();
});
else void health();
consent.onchange = async () => {
  if (extension) {
    const s = await cloudSettings();
    s.enabled = consent.checked;
    await chrome.storage.local.set({ briiCloud: s });
  }
  flow.invalidate(consent.checked ? "Cloud correction enabled. Type and press Space." : "Cloud correction off. No new text will be sent.");
  await health();
};
auto.onchange = () => flow.invalidate(auto.checked ? "Space correction enabled." : "Manual correction only.");
correct.onmousedown = (e) => e.preventDefault();
correct.onclick = () => flow.manual();
if (extension) chrome.storage.onChanged.addListener((c, a) => {
  if (a === "local" && c.briiCloud) {
    consent.checked = !!c.briiCloud.newValue?.enabled;
    flow.invalidate("Cloud settings changed.");
    correct.disabled = !configured || !consent.checked;
  }
});
window.addEventListener("pagehide", () => decoder.cancel());
