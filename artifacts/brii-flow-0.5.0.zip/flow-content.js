"use strict";
(() => {
  // src/brii/editor.ts
  var PlainEditor = class {
    constructor(element) {
      this.element = element;
    }
    get value() {
      return this.element.value;
    }
    get selectionStart() {
      return this.element.selectionStart ?? 0;
    }
    get selectionEnd() {
      return this.element.selectionEnd ?? 0;
    }
    get selectionDirection() {
      return this.element.selectionDirection ?? "none";
    }
    get scrollTop() {
      return this.element.scrollTop;
    }
    set scrollTop(value) {
      this.element.scrollTop = value;
    }
    get scrollLeft() {
      return this.element.scrollLeft;
    }
    set scrollLeft(value) {
      this.element.scrollLeft = value;
    }
    addEventListener(type, listener) {
      this.element.addEventListener(type, listener);
    }
    focus(options) {
      this.element.focus(options);
    }
    isFocused() {
      return document.activeElement === this.element;
    }
    setSelectionRange(start, end, direction = "none") {
      this.element.setSelectionRange(start, end, direction);
    }
    canReplace() {
      return true;
    }
    isAppend(previous, next, start, end) {
      return start === previous.length && end === previous.length && next.startsWith(previous);
    }
    atBoundary(position) {
      return position === this.value.length;
    }
    insertText(text) {
      return document.execCommand("insertText", false, text);
    }
  };
  var blocks = /* @__PURE__ */ new Set(["P", "DIV", "LI", "UL", "OL", "BLOCKQUOTE", "PRE", "H1", "H2", "H3", "H4", "H5", "H6"]);
  var RichSnapshot = class {
    constructor(root) {
      this.root = root;
      const emit = (value, before, after, text = false) => {
        const start = this.value.length;
        this.value += value;
        this.units.push({ start, end: this.value.length, before, after, text });
      };
      const walk = (node) => {
        const index = node.parentNode ? Array.prototype.indexOf.call(node.parentNode.childNodes, node) : 0;
        const before = { node: node.parentNode, offset: index }, after = { node: node.parentNode, offset: index + 1 };
        if (node instanceof Text) {
          const start2 = this.value.length;
          emit(node.data.replace(/\u00a0/g, " "), { node, offset: 0 }, { node, offset: node.length }, true);
          this.bounds.set(node, { start: start2, end: this.value.length });
          return;
        }
        if (!(node instanceof HTMLElement)) return;
        const block = node !== root && blocks.has(node.tagName);
        if (block && this.value && !this.value.endsWith("\n")) emit("\n", before, before);
        const start = this.value.length;
        if (node !== root && (node.contentEditable === "false" || node.matches('[data-private], [aria-readonly="true"], [hidden], [aria-hidden="true"]') || ["IMG", "HR", "INPUT", "TEXTAREA", "BUTTON", "IFRAME", "SCRIPT", "STYLE", "TEMPLATE"].includes(node.tagName))) emit("\uFFFC", before, after);
        else if (node.tagName === "BR") {
          if (node.nextSibling) emit("\n", before, after);
        } else for (const child of node.childNodes) walk(child);
        this.bounds.set(node, { start, end: this.value.length });
        if (block && (!this.value.endsWith("\n") || this.value.length === start)) emit("\n", after, after);
      };
      walk(root);
      while (this.units.length) {
        const last = this.units.at(-1);
        if (last.text || last.before.node !== last.after.node || last.before.offset !== last.after.offset) break;
        this.value = this.value.slice(0, last.start);
        this.units.pop();
      }
    }
    value = "";
    units = [];
    bounds = /* @__PURE__ */ new Map();
    index(node, offset) {
      if (!node || !this.root.contains(node)) return;
      const bound = this.bounds.get(node);
      if (!bound) return;
      if (node instanceof Text) return Math.min(this.value.length, bound.start + Math.min(offset, node.length));
      if (offset < node.childNodes.length) {
        const next = this.bounds.get(node.childNodes[offset]);
        if (next) return Math.min(this.value.length, next.start);
      }
      return Math.min(this.value.length, bound.end);
    }
    point(index, end = false) {
      if (index < 0 || index > this.value.length) return;
      const list = end ? [...this.units].reverse() : this.units;
      for (const unit of list) if (unit.text && index >= unit.start && index <= unit.end) return { node: unit.before.node, offset: index - unit.start };
      for (const unit of list) if (index >= unit.start && index <= unit.end) return end ? unit.after : unit.before;
      if (!this.value) return { node: this.root, offset: 0 };
    }
    range(start, end) {
      const a = this.point(start), b = this.point(end, true);
      if (!a || !b) return;
      const range = document.createRange();
      range.setStart(a.node, a.offset);
      range.setEnd(b.node, b.offset);
      return range;
    }
  };
  var inlineTags = /* @__PURE__ */ new Set(["B", "STRONG", "I", "EM", "U", "S", "STRIKE", "DEL", "SPAN", "A", "CODE", "SUB", "SUP", "MARK", "SMALL"]);
  var styleProperties = ["font-weight", "font-style", "text-decoration", "text-decoration-line", "color", "background-color", "font-family", "font-size", "vertical-align", "white-space"];
  function safeFragment(fragment) {
    for (const element of fragment.querySelectorAll("*")) {
      if (!(element instanceof HTMLElement) || !inlineTags.has(element.tagName) || element.contentEditable === "false") return false;
      const styles = styleProperties.map((p) => [p, element.style.getPropertyValue(p)]).filter(([, v]) => v && !/url\s*\(|expression\s*\(/i.test(v));
      const href = element.tagName === "A" ? element.getAttribute("href") : null, title = element.getAttribute("title"), className = element.getAttribute("class"), direction = element.getAttribute("dir"), language = element.getAttribute("lang");
      for (const attr of [...element.attributes]) element.removeAttribute(attr.name);
      for (const [name, value] of styles) element.style.setProperty(name, value);
      if (href) {
        try {
          const url = new URL(href, document.baseURI);
          if (!["https:", "http:", "mailto:", "tel:"].includes(url.protocol)) return false;
          element.setAttribute("href", href);
        } catch {
          return false;
        }
      }
      if (title) element.setAttribute("title", title);
      if (className) element.setAttribute("class", className);
      if (direction && ["ltr", "rtl", "auto"].includes(direction)) element.setAttribute("dir", direction);
      if (language) element.setAttribute("lang", language);
    }
    return true;
  }
  function correctedBoundaries(source, target) {
    const width = target.length + 1, table = new Uint16Array((source.length + 1) * width);
    for (let i2 = 0; i2 <= source.length; i2++) table[i2 * width] = i2;
    for (let j2 = 0; j2 <= target.length; j2++) table[j2] = j2;
    for (let i2 = 1; i2 <= source.length; i2++) for (let j2 = 1; j2 <= target.length; j2++) table[i2 * width + j2] = Math.min(table[(i2 - 1) * width + j2] + 1, table[i2 * width + j2 - 1] + 1, table[(i2 - 1) * width + j2 - 1] + (source[i2 - 1] === target[j2 - 1] ? 0 : 1));
    const boundaries = new Array(source.length + 1);
    let i = source.length, j = target.length;
    boundaries[i] = j;
    while (i || j) {
      const cost = table[i * width + j];
      if (i && j && cost === table[(i - 1) * width + j - 1] + (source[i - 1] === target[j - 1] ? 0 : 1)) {
        i--;
        j--;
        boundaries[i] = j;
      } else if (j && cost === table[i * width + j - 1] + 1) {
        j--;
        boundaries[i] = j;
      } else {
        i--;
        boundaries[i] = j;
      }
    }
    boundaries[0] = 0;
    boundaries[source.length] = target.length;
    return boundaries;
  }
  var RichEditor = class {
    constructor(element) {
      this.element = element;
    }
    snapshot() {
      return new RichSnapshot(this.element);
    }
    get value() {
      return this.snapshot().value;
    }
    selection() {
      const snapshot = this.snapshot(), selection = document.getSelection();
      const anchor = snapshot.index(selection?.anchorNode ?? null, selection?.anchorOffset ?? 0), focus = snapshot.index(selection?.focusNode ?? null, selection?.focusOffset ?? 0);
      return anchor === void 0 || focus === void 0 ? void 0 : { start: Math.min(anchor, focus), end: Math.max(anchor, focus), direction: anchor > focus ? "backward" : anchor === focus ? "none" : "forward" };
    }
    get selectionStart() {
      return this.selection()?.start ?? -1;
    }
    get selectionEnd() {
      return this.selection()?.end ?? -1;
    }
    get selectionDirection() {
      return this.selection()?.direction ?? "none";
    }
    get scrollTop() {
      return this.element.scrollTop;
    }
    set scrollTop(value) {
      this.element.scrollTop = value;
    }
    get scrollLeft() {
      return this.element.scrollLeft;
    }
    set scrollLeft(value) {
      this.element.scrollLeft = value;
    }
    addEventListener(type, listener) {
      this.element.addEventListener(type, listener);
    }
    focus(options) {
      this.element.focus(options);
    }
    isFocused() {
      return document.activeElement === this.element && !!this.selection();
    }
    setSelectionRange(start, end, direction = "none") {
      const snapshot = this.snapshot(), a = snapshot.point(start), b = snapshot.point(end, true), selection = document.getSelection();
      if (!a || !b || !selection) throw Error("Editor selection changed; correction cancelled.");
      if (direction === "backward") selection.setBaseAndExtent(b.node, b.offset, a.node, a.offset);
      else selection.setBaseAndExtent(a.node, a.offset, b.node, b.offset);
    }
    isAppend(previous, next, start, end) {
      return start === end && (start === previous.length || previous[start] === "\n") && next.length >= previous.length && next.startsWith(previous.slice(0, start)) && next.endsWith(previous.slice(start));
    }
    atBoundary(position) {
      const value = this.value;
      return position === value.length || value[position] === "\n";
    }
    canReplace(start, end) {
      const snapshot = this.snapshot();
      if (/[\n\ufffc]/.test(snapshot.value.slice(start, end))) return false;
      const range = snapshot.range(start, end);
      return !!range && safeFragment(range.cloneContents());
    }
    insertText(text) {
      if (/[\r\n]/.test(text)) return false;
      const selected = this.selection();
      if (!selected || !this.canReplace(selected.start, selected.end)) return false;
      const range = this.snapshot().range(selected.start, selected.end);
      const fragment = range.cloneContents();
      if (!safeFragment(fragment)) return false;
      if (!fragment.querySelector("*")) return document.execCommand("insertText", false, text);
      const walker = document.createTreeWalker(fragment, NodeFilter.SHOW_TEXT), nodes = [];
      while (walker.nextNode()) nodes.push(walker.currentNode);
      const source = nodes.map((n) => n.data.replace(/\u00a0/g, " ")).join(""), boundaries = correctedBoundaries(source, text);
      let at = 0;
      for (const node of nodes) {
        const end = at + node.length;
        node.data = text.slice(boundaries[at], boundaries[end]);
        at = end;
      }
      const container = document.createElement("div");
      container.append(fragment);
      return document.execCommand("insertHTML", false, container.innerHTML);
    }
  };

  // src/brii/decoding.ts
  var MAX_SEGMENT = 600;
  function sentenceStart(value, end) {
    const prefix = value.slice(0, end), trimmedEnd = prefix.trimEnd().length;
    let start = prefix.lastIndexOf("\n") + 1;
    for (const match of prefix.matchAll(/[.!?]["')\]]*\s+/g)) {
      const after = match.index + match[0].length;
      if (after <= trimmedEnd) start = Math.max(start, after);
    }
    return start;
  }
  function segmentAt(value, end, frontier, manual = false) {
    if (end < 0 || end > value.length || !manual && !/\s$/.test(value.slice(0, end))) return;
    let start = manual ? sentenceStart(value, end) : Math.min(frontier, end);
    while (start < end && /\s/.test(value[start])) start++;
    const raw = value.slice(start, end).trimEnd();
    if (!raw.trim()) return;
    if (raw.length > MAX_SEGMENT) throw Error(`Correction chunk exceeds ${MAX_SEGMENT} characters. Use shorter bursts or place the caret in a shorter sentence and use manual correction.`);
    return { start, end: start + raw.length, raw, context: value.slice(Math.max(0, start - 400), start), prefix: value.slice(0, start + raw.length) };
  }
  function planReplacement(segment, corrected, current, selection) {
    if (!current.startsWith(segment.prefix) || selection.start < segment.end || selection.end < segment.end) return;
    const delta = corrected.length - (segment.end - segment.start);
    return { start: segment.start, end: segment.end, text: corrected, delta, selection: { ...selection, start: selection.start + delta, end: selection.end + delta } };
  }

  // src/brii/rolling.ts
  function rawBoundaries(raw, text) {
    const width = text.length + 1, table = new Uint16Array((raw.length + 1) * width);
    for (let i2 = 0; i2 <= raw.length; i2++) table[i2 * width] = i2;
    for (let j2 = 0; j2 <= text.length; j2++) table[j2] = j2;
    for (let i2 = 1; i2 <= raw.length; i2++) for (let j2 = 1; j2 <= text.length; j2++) table[i2 * width + j2] = Math.min(table[(i2 - 1) * width + j2] + 1, table[i2 * width + j2 - 1] + 1, table[(i2 - 1) * width + j2 - 1] + (raw[i2 - 1] === text[j2 - 1] ? 0 : 1));
    const boundary = new Array(width);
    let i = raw.length, j = text.length;
    boundary[j] = i;
    while (i || j) {
      const cost = table[i * width + j];
      if (i && j && cost === table[(i - 1) * width + j - 1] + (raw[i - 1] === text[j - 1] ? 0 : 1)) {
        i--;
        j--;
        boundary[j] = i;
      } else if (i && cost === table[(i - 1) * width + j] + 1) {
        i--;
        boundary[j] = i;
      } else {
        j--;
        boundary[j] = i;
      }
    }
    boundary[0] = 0;
    boundary[text.length] = raw.length;
    return boundary;
  }
  var RollingDraft = class {
    revisions = [];
    protectedEnd = 0;
    protect(end) {
      this.revisions = [];
      this.protectedEnd = end;
    }
    segment(value, boundary, wholeSentence = false, manual = false) {
      let start = Math.max(manual ? 0 : this.protectedEnd, sentenceStart(value, boundary));
      const end = value.slice(0, boundary).trimEnd().length;
      if (end <= start) return;
      if (!wholeSentence) {
        const words = [...value.slice(start, end).matchAll(/\S+/g)];
        if (words.length > 12) start += words[words.length - 12].index;
      }
      for (const revision of this.revisions) if (revision.start < start && revision.end > start) start = revision.start;
      while (start < end && /\s/.test(value[start])) start++;
      const shown = value.slice(start, end);
      if (!shown.trim()) return;
      let raw = "", at = start;
      for (const revision of this.revisions) {
        if (revision.start < start || revision.end > end) continue;
        raw += value.slice(at, revision.start) + revision.raw;
        at = revision.end;
      }
      raw += value.slice(at, end);
      if (raw.length > MAX_SEGMENT || shown.length > MAX_SEGMENT) throw Error(`Correction chunk exceeds ${MAX_SEGMENT} characters. Finish this sentence before continuing.`);
      return { start, end, raw, context: value.slice(Math.max(0, start - 400), start), prefix: value.slice(0, end) };
    }
    applied(segment, text) {
      const delta = text.length - (segment.end - segment.start);
      if (segment.start < this.protectedEnd) this.protectedEnd = Math.max(segment.start, this.protectedEnd + delta);
      this.revisions = this.revisions.filter((r) => r.end <= segment.start || r.start >= segment.end).map((r) => r.start >= segment.end ? { ...r, start: r.start + delta, end: r.end + delta } : r);
      const boundaries = rawBoundaries(segment.raw, text);
      for (const word of text.matchAll(/\S+|\s+/g)) {
        const start = word.index, end = start + word[0].length;
        this.revisions.push({ start: segment.start + start, end: segment.start + end, raw: segment.raw.slice(boundaries[start], boundaries[end]) });
      }
      this.revisions.sort((a, b) => a.start - b.start);
    }
  };

  // src/brii/flow.ts
  var BriiFlow = class {
    constructor(editor, options) {
      this.options = options;
      this.editor = editor instanceof HTMLTextAreaElement || editor instanceof HTMLInputElement ? new PlainEditor(editor) : editor;
      this.previous = this.editor.value;
      this.editor.addEventListener("beforeinput", () => {
        if (!this.applying && this.active()) this.before = { start: this.editor.selectionStart, end: this.editor.selectionEnd };
      });
      this.editor.addEventListener("input", (e) => this.input(e));
      this.editor.addEventListener("compositionstart", () => {
        this.composing = true;
        if (this.active()) this.invalidate("IME composition: correction paused.");
      });
      this.editor.addEventListener("compositionend", () => {
        this.composing = false;
        if (this.active()) this.previous = this.editor.value;
      });
      this.editor.addEventListener("keydown", (e) => {
        if (this.active() && (!this.options.trustedOnly || e.isTrusted) && (e.ctrlKey || e.metaKey) && e.key === "Enter" && !e.isComposing) {
          e.preventDefault();
          this.manual();
        }
      });
    }
    draft = new RollingDraft();
    pauseTimer;
    epoch = 0;
    frontier = 0;
    pending = false;
    applying = false;
    composing = false;
    previous;
    before;
    queued;
    timer;
    editor;
    active() {
      return this.options.active?.() ?? true;
    }
    get isBusy() {
      return this.pending;
    }
    invalidate(message = "Pending corrections cancelled.") {
      clearTimeout(this.pauseTimer);
      this.epoch++;
      this.queued = void 0;
      clearTimeout(this.timer);
      if (this.active()) {
        this.frontier = sentenceStart(this.editor.value, this.editor.selectionStart);
        this.previous = this.editor.value;
      } else {
        this.frontier = 0;
        this.previous = "";
        this.draft.protect(0);
      }
      if (this.pending) this.options.cancel();
      this.options.status(message);
    }
    manual() {
      if (this.composing || !this.active()) return;
      this.editor.focus({ preventScroll: true });
      if (this.editor.selectionStart !== this.editor.selectionEnd) {
        this.options.status("Collapse the selection first. Selected text is never overwritten.");
        return;
      }
      this.enqueue(this.editor.selectionStart, true);
    }
    input(event) {
      if (this.applying || !this.active() || this.options.trustedOnly && !event.isTrusted) return;
      const value = this.editor.value;
      clearTimeout(this.pauseTimer);
      const history = event.inputType === "historyUndo" || event.inputType === "historyRedo";
      const appendOnly = !!this.before && this.editor.isAppend(this.previous, value, this.before.start, this.before.end);
      this.before = void 0;
      if (history || !appendOnly) this.invalidate(history ? "Undo/redo preserved. Type another Space to resume." : "Edit invalidated the previous correction.");
      if (this.options.rolling && (history || !appendOnly)) this.draft.protect(value.length);
      this.previous = value;
      if (this.composing || event.isComposing || history) return;
      if (this.options.automatic() && event.inputType === "insertText" && event.data === " " && this.editor.selectionStart === this.editor.selectionEnd) this.enqueue(this.editor.selectionStart, false);
      if (this.options.rolling && this.options.automatic() && event.inputType === "insertText" && appendOnly) {
        const epoch = this.epoch;
        this.pauseTimer = setTimeout(() => {
          if (epoch !== this.epoch || !this.active() || !this.options.automatic() || !this.editor.atBoundary(this.editor.selectionStart) || this.editor.selectionEnd !== this.editor.selectionStart) return;
          const boundary = this.editor.selectionStart, prefix = this.editor.value.slice(0, boundary);
          const completed = /[.!?]$/.test(prefix) ? boundary : prefix.search(/\S*$/);
          if (completed > 0) this.enqueue(completed, false, true);
        }, 650);
      }
    }
    enqueue(boundary, manual, wholeSentence = false) {
      if (!this.options.ready()) {
        this.options.status("Decoder is not ready. Check the connection or model; raw typing continues normally.");
        return;
      }
      const at = performance.now();
      this.queued = { boundary, manual, wholeSentence, epoch: this.epoch, due: at + (manual ? 0 : this.options.delay()), at };
      this.options.status(this.pending ? "Queued the latest completed text; current inference continues." : "Waiting for the short Space debounce\u2026");
      this.drain();
    }
    drain() {
      clearTimeout(this.timer);
      if (this.pending || !this.queued || this.composing) return;
      const wait = this.queued.due - performance.now();
      if (wait > 0) {
        this.timer = setTimeout(() => this.drain(), wait);
        return;
      }
      const queued = this.queued;
      this.queued = void 0;
      if (!this.options.ready() || queued.epoch !== this.epoch || !queued.manual && !this.options.automatic() || !this.editor.isFocused() || this.editor.selectionStart < queued.boundary) {
        this.options.status("Queued correction skipped after focus, selection, model, or mode changed.");
        return;
      }
      let segment;
      try {
        segment = this.options.rolling ? this.draft.segment(this.editor.value, queued.boundary, queued.wholeSentence || queued.manual, queued.manual) : segmentAt(this.editor.value, queued.boundary, this.frontier, queued.manual);
      } catch (e) {
        this.options.status(String(e));
        return;
      }
      if (!segment) return;
      if (!this.editor.canReplace(segment.start, segment.end)) {
        this.options.status("This range contains unsupported formatting or embedded content; original text preserved.");
        return;
      }
      const started = queued.at;
      this.pending = true;
      this.options.status(this.options.decodingStatus || "Decoding locally\u2026 keep typing.");
      void this.options.decode(segment.raw, segment.context).then((result) => {
        let applied = false, unchanged = false, reason = result.validationError ? "Correction not applied: " + result.validationError : "Result discarded after an edit, selection change, blur, or composition.";
        if (this.active() && !result.validationError && queued.epoch === this.epoch && !this.composing && this.editor.isFocused()) {
          const selection = { start: this.editor.selectionStart, end: this.editor.selectionEnd, direction: this.editor.selectionDirection };
          const plan = planReplacement(segment, result.corrected, this.editor.value, selection);
          if (plan) {
            if (this.editor.value.slice(segment.start, segment.end) === result.corrected) {
              unchanged = true;
              reason = "The model returned the text unchanged. It may not have decoded it; the next completed words will be included in another attempt.";
            } else {
              const scrollTop = this.editor.scrollTop, scrollLeft = this.editor.scrollLeft;
              this.applying = true;
              try {
                this.editor.setSelectionRange(plan.start, plan.end);
                applied = this.editor.insertText(plan.text);
                if (applied) {
                  this.editor.setSelectionRange(plan.selection.start, plan.selection.end, plan.selection.direction);
                  reason = "Correction applied; ordinary Undo restores the raw text.";
                } else {
                  this.editor.setSelectionRange(selection.start, selection.end, selection.direction);
                  reason = "Browser rejected native insertion; original text preserved.";
                }
              } finally {
                this.applying = false;
                this.previous = this.editor.value;
                this.editor.scrollTop = scrollTop;
                this.editor.scrollLeft = scrollLeft;
              }
            }
            if (applied) {
              if (this.options.rolling) this.draft.applied(segment, plan.text);
              this.frontier = plan.start + plan.text.length;
              if (this.queued && this.queued.boundary >= plan.end) this.queued.boundary += plan.delta;
            }
          }
        }
        this.options.result({ segment, result, applied, unchanged, reason, elapsedMs: performance.now() - started });
        this.options.status(reason);
      }).catch((e) => this.options.status("Correction failed; original text preserved. " + String(e))).finally(() => {
        this.pending = false;
        this.drain();
        this.options.changed?.();
      });
    }
  };

  // src/brii/cloud-client.ts
  var CloudDecoder = class {
    constructor(send) {
      this.send = send;
    }
    current;
    async decode(text, context) {
      const requestId = crypto.randomUUID();
      this.current = requestId;
      const start = performance.now();
      try {
        const data = await this.send({ kind: "decode", requestId, text, context });
        if (data.error) throw Error(data.error);
        if (typeof data.corrected !== "string" || !data.corrected.trim() || data.corrected.length > 1800) throw Error("Invalid cloud correction; original text was preserved.");
        return { corrected: data.corrected, rawOutput: data.corrected, ttftMs: null, totalMs: performance.now() - start, finishReason: "complete" };
      } finally {
        if (this.current === requestId) this.current = void 0;
      }
    }
    cancel() {
      if (this.current) void this.send({ kind: "cancel", requestId: this.current }).catch(() => {
      });
    }
  };
  var extensionTransport = (message) => chrome.runtime.sendMessage({ target: "briiCloud", ...message });

  // src/brii/cloud.ts
  var cloudDefaults = { enabled: false, automatic: true, sites: [], delay: 80 };
  var cloudSettings = async () => ({ ...cloudDefaults, ...(await chrome.storage.local.get("briiCloud")).briiCloud || {} });
  function cloudAllowed(url, s) {
    try {
      return s.enabled && s.sites.includes(new URL(url).origin);
    } catch {
      return false;
    }
  }
  function cloudFrameAllowed(url, origin, s) {
    if (url === "about:blank" || url === "about:srcdoc") return !!origin && cloudAllowed(origin, s);
    return cloudAllowed(url, s);
  }

  // src/shared.ts
  function safeField(el) {
    if (!(el instanceof HTMLTextAreaElement || el instanceof HTMLInputElement)) return false;
    if (el instanceof HTMLInputElement && !["text", "search"].includes(el.type)) return false;
    return !el.disabled && !el.readOnly && safeEditorMetadata(el);
  }
  function safeEditorMetadata(el) {
    return !el.closest('[data-private], [aria-readonly="true"], [aria-disabled="true"]') && !/password|one-time|cc-|username|email|tel|address|name|birth|transaction|ssn|social.?security|credit.?card|card.?number|cvv|bank|routing|api.?key|secret|token|otp/i.test(["autocomplete", "name", "id", "aria-label"].map((a) => el.getAttribute(a) || "").join(" "));
  }
  function richHost(el) {
    if (!(el instanceof HTMLElement) || !el.isContentEditable) return;
    let host = el;
    while (host.parentElement?.isContentEditable) host = host.parentElement;
    return safeEditorMetadata(host) ? host : void 0;
  }

  // src/flow-content.ts
  var global = globalThis;
  if (!global.__briiFlow) {
    let show = function(message) {
      if (!active()) {
        host.remove();
        return;
      }
      if (!host.isConnected) document.documentElement.append(host);
      status.textContent = "Brii \xB7 OpenAI \xB7 " + message;
    }, attach = function(target) {
      if (!active()) return;
      const element = safeField(target) ? target : richHost(target);
      if (!element) {
        if (target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement || target instanceof HTMLElement && target.isContentEditable) show("This field is excluded from cloud correction.");
        return;
      }
      const plain = safeField(element);
      show(`Ready in this ${plain ? "field" : "rich-text editor"} \xB7 type, then Space or Cmd/Ctrl+Enter`);
      if (known.has(element)) return;
      for (const item of flows) if (!item.element.isConnected) {
        item.flow.invalidate();
        flows.delete(item);
      }
      known.add(element);
      const decoder = new CloudDecoder(extensionTransport);
      const flow = new BriiFlow(plain ? element : new RichEditor(element), { rolling: true, active: () => active() && (plain ? safeField(element) : richHost(element) === element), trustedOnly: true, ready: active, automatic: () => !!config?.automatic, delay: () => config?.delay ?? 80, decodingStatus: "Decoding with OpenAI\u2026 keep typing.", decode: (text, context) => decoder.decode(text, context), cancel: () => decoder.cancel(), status: show, result: (r) => {
        if (r.applied) show(`Corrected \xB7 ${Math.round(r.result.totalMs)} ms \xB7 Undo to restore`);
      } });
      flows.add({ element, flow });
    };
    show2 = show, attach2 = attach;
    global.__briiFlow = true;
    let config;
    const flows = /* @__PURE__ */ new Set();
    const known = /* @__PURE__ */ new WeakSet();
    const host = document.createElement("div");
    host.dataset.briiStatus = "";
    host.style.cssText = "position:fixed;right:12px;bottom:12px;z-index:2147483647;pointer-events:none;";
    const shadow = host.attachShadow({ mode: "closed" });
    const status = document.createElement("div");
    status.style.cssText = "font:12px/1.5 system-ui;background:#173a2b;color:white;padding:7px 12px;border-radius:5px;max-width:400px;";
    status.setAttribute("role", "status");
    shadow.append(status);
    const active = () => !!config && cloudFrameAllowed(location.href, globalThis.origin, config);
    document.addEventListener("focusin", (event) => {
      if (event.isTrusted) attach(event.target);
    }, true);
    void cloudSettings().then((s) => {
      config = s;
      attach(document.activeElement);
    });
    chrome.storage.onChanged.addListener((c, a) => {
      if (a === "local" && c.briiCloud) {
        config = c.briiCloud.newValue;
        for (const item of flows) item.flow.invalidate("Cloud correction settings changed.");
        if (!active()) host.remove();
        else attach(document.activeElement);
      }
    });
  }
  var show2;
  var attach2;
})();
