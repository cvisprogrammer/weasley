// src/brii/cloud.ts
var cloudDefaults = { enabled: false, automatic: true, sites: [], delay: 80 };
var cloudSettings = async () => ({ ...cloudDefaults, ...(await chrome.storage.local.get("briiCloud")).briiCloud || {} });

// src/shared.ts
function matchPattern(origin) {
  const u = new URL(origin);
  return `${u.protocol}//${u.hostname}/*`;
}

// src/brii/cloud-client.ts
var extensionTransport = (message) => chrome.runtime.sendMessage({ target: "briiCloud", ...message });

// src/flow-popup.ts
var $ = (id) => document.getElementById(id);
var input = (id) => $(id);
var s = await cloudSettings();
input("enabled").checked = s.enabled;
input("automatic").checked = s.automatic;
input("delay").value = String(s.delay);
var save = async () => {
  await chrome.storage.local.set({ briiCloud: s });
};
async function injectActive() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (s.enabled && tab?.id && tab.url && s.sites.includes(new URL(tab.url).origin)) await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["flow-content.js"] });
}
for (const key of ["enabled", "automatic"]) input(key).onchange = async () => {
  s[key] = input(key).checked;
  await save();
  if (key === "enabled" && s.enabled) await injectActive();
};
input("delay").onchange = async () => {
  s.delay = Math.max(0, Math.min(1e3, Number(input("delay").value) || 0));
  await save();
};
function render() {
  $("sites").replaceChildren();
  for (const origin of s.sites) {
    const li = document.createElement("li");
    li.textContent = origin + " ";
    const remove = document.createElement("button");
    remove.textContent = "Remove";
    remove.onclick = async () => {
      s.sites = s.sites.filter((x) => x !== origin);
      await save();
      if (!s.sites.some((x) => matchPattern(x) === matchPattern(origin))) await chrome.permissions.remove({ origins: [matchPattern(origin)] });
      render();
    };
    li.append(remove);
    $("sites").append(li);
  }
}
render();
$("allow").onclick = async () => {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const url = new URL(tab.url || "");
    if (!["http:", "https:"].includes(url.protocol)) throw Error("Open a normal website first.");
    if (await chrome.permissions.request({ origins: [matchPattern(url.origin)] })) {
      s.sites = [.../* @__PURE__ */ new Set([...s.sites, url.origin])];
      await save();
      if (tab.id && s.enabled) await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["flow-content.js"] });
      render();
      $("status").textContent = s.enabled ? "Website allowed. Type in an ordinary text field." : "Website allowed. Enable cloud corrections when ready.";
    }
  } catch (e) {
    $("status").textContent = String(e);
  }
};
$("try").onclick = () => void chrome.tabs.create({ url: chrome.runtime.getURL("cloud-playground.html") });
async function health() {
  try {
    const h = await extensionTransport({ kind: "health" });
    $("status").textContent = h.error || (!h.enabled ? "Bridge is running; set OPENAI_API_KEY and restart it." : `Bridge ready \xB7 ${h.model} \xB7 cloud corrections ${s.enabled ? "enabled" : "off"}`);
  } catch {
    $("status").textContent = "Bridge not running. Start npm run cloud in your terminal.";
  }
}
void health();
