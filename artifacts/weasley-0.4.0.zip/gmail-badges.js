"use strict";
(() => {
  // src/mail/types.ts
  var BADGE_TTL = 15 * 60 * 1e3;

  // src/mail/identity.ts
  function canonicalEmail(value) {
    const email = value.toLowerCase().trim();
    const [local, domain] = email.split("@");
    return domain === "gmail.com" || domain === "googlemail.com" ? local.split("+")[0].replace(/\./g, "") + "@gmail.com" : email;
  }

  // src/mail/badges.ts
  function threadId(raw) {
    if (!raw) return;
    const value = raw.replace(/^#/, "");
    if (/^[a-f0-9]{8,32}$/i.test(value)) return value.toLowerCase();
    const decimal = value.match(/^thread-f:(\d+)$/);
    if (decimal) {
      try {
        return BigInt(decimal[1]).toString(16);
      } catch {
      }
    }
  }
  function visibleAccount(doc) {
    const nodes = doc.querySelectorAll('a[href^="https://accounts.google.com/SignOutOptions"]');
    for (const node of nodes) {
      if (!node.checkVisibility({ checkVisibilityCSS: true })) continue;
      const label = node.getAttribute("aria-label") || "";
      const email = label.match(/[a-z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-z0-9.-]+\.[a-z]{2,}/i)?.[0];
      if (email) return canonicalEmail(email);
    }
  }
  function usableBadge(cache, account, id, dirtyAt = 0, now = Date.now()) {
    if (!cache || canonicalEmail(cache.account) !== canonicalEmail(account)) return;
    return cache.entries.find((entry) => entry.threadId === id && entry.checkedAt >= dirtyAt && now - entry.checkedAt <= BADGE_TTL);
  }

  // src/gmail-badges.ts
  var global = globalThis;
  if (!global.__weasleyBadges) {
    let queue = function() {
      clearTimeout(timer);
      timer = setTimeout(() => void refresh(), 120);
    };
    queue2 = queue;
    global.__weasleyBadges = true;
    const dirty = /* @__PURE__ */ new Map();
    let timer, running = false, again = false, alive = true;
    const rows = () => [...document.querySelectorAll('tr.zA,[role="row"][data-thread-id]')];
    const idFor = (row) => threadId(row.getAttribute("data-legacy-thread-id")) || threadId(row.querySelector("[data-legacy-thread-id]")?.getAttribute("data-legacy-thread-id") || null) || threadId(row.getAttribute("data-thread-id")) || threadId(row.querySelector("[data-thread-id]")?.getAttribute("data-thread-id") || null);
    const remove = () => document.querySelectorAll("[data-weasley-reply]").forEach((e) => e.remove());
    async function refresh() {
      if (!alive) return;
      if (running) {
        again = true;
        return;
      }
      running = true;
      try {
        const account = visibleAccount(document), list = rows();
        if (!account) {
          remove();
          return;
        }
        const ids = list.map(idFor).filter((id) => !!id);
        const response = await chrome.runtime.sendMessage({ target: "gmailBadges", account, ids });
        if (!alive) return;
        const cache = { account, entries: response?.entries || [] };
        for (const row of list) {
          const id = idFor(row), entry = id ? usableBadge(cache, account, id, dirty.get(id) || 0) : void 0;
          let badge = row.querySelector("[data-weasley-reply]");
          if (!entry || entry.checkedAt < (dirty.get(id) || 0)) {
            badge?.remove();
            continue;
          }
          const cell = row.querySelector("td.a4W,.a4W,[data-weasley-subject]");
          if (!cell) continue;
          const subject = cell.querySelector(".y6") || cell.querySelector(".bog")?.parentElement || cell;
          const title = "Needs your reply \u2014 " + entry.evidence + "\nChecked " + new Date(entry.checkedAt).toLocaleTimeString() + ". Rescan after new activity.";
          if (!badge) {
            badge = document.createElement("span");
            badge.dataset.weasleyReply = "";
            badge.setAttribute("role", "img");
            badge.textContent = "\u21A9 Reply";
            badge.style.cssText = "display:inline-flex;align-items:center;white-space:nowrap;flex:0 0 auto;min-width:48px;margin-right:8px;padding:1px 5px;border-radius:4px;background:#e8f0fe;color:#174ea6;font:600 11px/18px system-ui;vertical-align:middle;";
            subject.prepend(badge);
          }
          if (badge.title !== title) {
            badge.title = title;
            badge.setAttribute("aria-label", title);
          }
        }
      } catch {
        remove();
      } finally {
        running = false;
        if (again) {
          again = false;
          queue();
        }
      }
    }
    const observer = new MutationObserver((records) => {
      let external = false;
      for (const record of records) {
        const target = record.target instanceof Element ? record.target : record.target.parentElement;
        if (target?.closest("[data-weasley-reply]")) continue;
        if (record.type === "childList" && [...record.addedNodes, ...record.removedNodes].length && [...record.addedNodes, ...record.removedNodes].every((n) => n instanceof Element && n.hasAttribute("data-weasley-reply"))) continue;
        external = true;
        const row = target?.closest('tr.zA,[role="row"][data-thread-id]');
        const id = row ? idFor(row) : void 0;
        if (id) dirty.set(id, Date.now());
      }
      if (external) queue();
    });
    observer.observe(document.body, { subtree: true, childList: true, characterData: true, attributes: true, attributeFilter: ["data-thread-id", "data-legacy-thread-id", "aria-label"] });
    const interval = setInterval(queue, 6e4);
    const onMessage = (m, sender) => {
      if (sender.id !== chrome.runtime.id) return;
      if (m.target === "gmailBadgeRefresh") queue();
      if (m.target === "gmailBadgeDisconnect") {
        alive = false;
        observer.disconnect();
        clearInterval(interval);
        clearTimeout(timer);
        remove();
        global.__weasleyBadges = false;
        chrome.runtime.onMessage.removeListener(onMessage);
      }
    };
    chrome.runtime.onMessage.addListener(onMessage);
    queue();
  }
  var queue2;
})();
