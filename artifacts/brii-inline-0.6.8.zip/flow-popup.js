// src/brii/trigger.ts
var commandTriggers = [";;", "//", "--", "\\\\"];
function selectedTrigger(value) {
  return commandTriggers.includes(value) ? value : ";;";
}

// src/brii/cloud.ts
var cloudDefaults = { includePageContext: true, commandTrigger: ";;", enabled: false, automatic: true, sites: [], delay: 80 };
var cloudSettings = async () => {
  const stored = (await chrome.storage.local.get("briiCloud")).briiCloud;
  return { ...cloudDefaults, ...stored, commandTrigger: selectedTrigger(stored?.commandTrigger) };
};

// src/shared.ts
function matchPattern(origin) {
  const u = new URL(origin);
  return `${u.protocol}//${u.hostname}/*`;
}

// src/brii/cloud-client.ts
var extensionTransport = (message) => chrome.runtime.sendMessage({ target: "briiCloud", ...message });

// src/flow-popup.ts
var $ = (id) => document.getElementById(id);
var input = (id) => $(id);
var s = await cloudSettings();
input("enabled").checked = s.enabled;
input("includePageContext").checked = s.includePageContext !== false;
var trigger = $("commandTrigger");
for (const marker of commandTriggers) trigger.add(new Option(marker === ";;" ? ";; (recommended for Gmail)" : marker, marker));
trigger.value = selectedTrigger(s.commandTrigger);
function triggerHint() {
  const m = trigger.value;
  $("triggerHelp").textContent = `Type ${m}instruction${m}, or ${m}instruction then Enter. ${m}...${m} continues a sentence.`;
}
triggerHint();
var save = async (patch) => {
  s = { ...await cloudSettings(), ...patch };
  await chrome.storage.local.set({ briiCloud: s });
};
trigger.onchange = async () => {
  triggerHint();
  await save({ commandTrigger: selectedTrigger(trigger.value) });
  $("status").textContent = `Command trigger set to ${s.commandTrigger}. Applies to allowed pages immediately.`;
};
input("includePageContext").onchange = async () => {
  await save({ includePageContext: input("includePageContext").checked });
  $("status").textContent = s.includePageContext ? "Visible page/thread context enabled for commands." : "Page/thread context off. Commands use only your editor text.";
};
async function activeWebsite() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const parse = (value) => {
    try {
      const url2 = new URL(value || "");
      return ["http:", "https:"].includes(url2.protocol) ? url2 : void 0;
    } catch {
      return void 0;
    }
  };
  let url = parse(tab?.url) || parse(tab?.pendingUrl);
  if (!url && tab?.id !== void 0) try {
    const [result] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: () => location.href });
    url = parse(result?.result);
  } catch {
  }
  if (!url || tab?.id === void 0) throw Error("Cannot access this website. Open its page, then click the Brii toolbar icon and try Allow this website again. Chrome internal pages are not supported.");
  return { tab, url };
}
async function injectActive() {
  try {
    const { tab, url } = await activeWebsite();
    if (s.enabled && s.sites.includes(url.origin)) await chrome.scripting.executeScript({ target: { tabId: tab.id, allFrames: true }, files: ["flow-content.js"] });
  } catch (e) {
    $("status").textContent = String(e);
  }
}
input("enabled").onchange = async () => {
  await save({ enabled: input("enabled").checked });
  if (s.enabled) await injectActive();
};
function render() {
  $("sites").replaceChildren();
  for (const origin of s.sites) {
    const li = document.createElement("li");
    li.textContent = origin + " ";
    const remove = document.createElement("button");
    remove.textContent = "Remove";
    remove.onclick = async () => {
      await save({ sites: s.sites.filter((x) => x !== origin) });
      if (!s.sites.some((x) => matchPattern(x) === matchPattern(origin))) await chrome.permissions.remove({ origins: [matchPattern(origin)] });
      render();
      websiteStatus();
    };
    li.append(remove);
    $("sites").append(li);
  }
}
var prepared;
function websiteStatus() {
  const current = prepared?.origin;
  $("websiteStatus").textContent = current ? `${current} \xB7 ${s.sites.includes(current) ? "allowed" : "not allowed"} \xB7 commands ${s.enabled ? "on" : "off"}` : "Open a website to allow it.";
}
async function prepareWebsite() {
  const { tab, url } = await activeWebsite();
  if (prepared?.origin !== url.origin || prepared.tabId !== tab.id) {
    const response = await extensionTransport({ kind: "prepareSite", origin: url.origin, tabId: tab.id });
    if (response.error) throw Error(response.error);
    prepared = { origin: url.origin, tabId: tab.id };
  }
  websiteStatus();
  return { tab, url };
}
render();
var preparing = prepareWebsite().catch(() => {
  websiteStatus();
  return void 0;
});
$("allow").onclick = async () => {
  const button = $("allow");
  button.disabled = true;
  try {
    await preparing;
    const { tab, url } = await prepareWebsite();
    if (!await chrome.permissions.request({ origins: [matchPattern(url.origin)] })) {
      await extensionTransport({ kind: "cancelSite", origin: url.origin, tabId: tab.id });
      $("status").textContent = "Website permission was not granted.";
      return;
    }
    const result = await extensionTransport({ kind: "finishSite", origin: url.origin, tabId: tab.id });
    if (result.error) throw Error(result.error);
    if (!result.saved) throw Error("Website access was not saved. Reopen Brii to retry.");
    s = await cloudSettings();
    render();
    websiteStatus();
    $("status").textContent = !s.enabled ? "Website allowed. Enable cloud commands when ready." : result.attached === false ? "Website allowed and saved. Refresh this tab to attach Brii." : `Website allowed. Type ${selectedTrigger(s.commandTrigger)}instruction${selectedTrigger(s.commandTrigger)} in a text field.`;
  } catch (e) {
    $("status").textContent = String(e);
  } finally {
    button.disabled = false;
  }
};
chrome.storage.onChanged?.addListener((changes, area) => {
  if (area === "local" && changes.briiCloud) void cloudSettings().then((settings) => {
    s = settings;
    input("enabled").checked = s.enabled;
    input("includePageContext").checked = s.includePageContext !== false;
    trigger.value = selectedTrigger(s.commandTrigger);
    triggerHint();
    render();
    websiteStatus();
  });
});
$("try").onclick = () => void chrome.tabs.create({ url: chrome.runtime.getURL("inline-playground.html") });
async function health() {
  try {
    const h = await extensionTransport({ kind: "health" });
    $("status").textContent = h.error || (h.commandStrategy !== "inline-commands-v5" ? "Bridge is outdated. Stop it with Ctrl+C and restart npm run cloud." : !h.enabled ? "Bridge is running; set OPENAI_API_KEY and restart it." : `Bridge ready \xB7 ${h.model} \xB7 cloud commands ${s.enabled ? "enabled" : "off"}`);
  } catch {
    $("status").textContent = "Bridge not running. Start npm run cloud in your terminal.";
  }
}
void health();
