"use strict";
(() => {
  // src/brii/commands.ts
  function commandAt(value, caret, trigger) {
    if (caret < 0 || caret > value.length) return;
    if (trigger === "enter" && caret < value.length && value[caret] !== "\n") return;
    const lineStart = value.lastIndexOf("\n", caret - 1) + 1, line = value.slice(lineStart, caret);
    let found;
    for (let open = 0; open < line.length - 1; open++) {
      if (line.slice(open, open + 2) !== "//" || open > 0 && !/\s/.test(line[open - 1])) continue;
      let close = -1;
      for (let i = open + 2; i < line.length - 1; i++) if (line.slice(i, i + 2) === "//" && ![":", "\\"].includes(line[i - 1])) {
        close = i;
        break;
      }
      const end = close < 0 ? line.length : close + 2, instruction = line.slice(open + 2, close < 0 ? line.length : close).trim();
      if (instruction && (trigger === "enter" || close >= 0 && end === line.length)) {
        const markerStart = lineStart + open, markerEnd = lineStart + end, nextBreak = value.indexOf("\n", caret), lineEnd = nextBreak < 0 ? value.length : nextBreak;
        const lineText = value.slice(lineStart, markerStart) + value.slice(markerEnd, lineEnd), continuation = ["...", "\u2026"].includes(instruction), rewrite = !continuation && !!lineText.trim();
        const start = rewrite ? lineStart : markerStart, absoluteEnd = rewrite ? lineEnd : markerEnd;
        found = { start, end: absoluteEnd, instruction, mode: continuation ? "continue" : rewrite ? "rewrite-line" : "write", scope: rewrite ? "line" : "command", lineText: rewrite ? lineText : "", before: value.slice(Math.max(0, start - 1200), start), after: value.slice(absoluteEnd, absoluteEnd + 400), prefix: value.slice(0, absoluteEnd) };
      }
      if (close < 0) break;
      open = close + 1;
    }
    return found;
  }
  var InlineCommands = class {
    constructor(editor, element, options) {
      this.editor = editor;
      this.element = element;
      this.options = options;
      const listen = (target, type, fn, capture = false) => {
        target.addEventListener(type, fn, capture);
        this.listeners.push({ target, type, listener: fn, capture });
      };
      listen(document, "keydown", (e) => this.key(e), true);
      listen(element, "compositionstart", () => {
        this.composing = true;
        this.invalidate("Composition in progress; command paused.");
      });
      listen(element, "compositionend", () => {
        this.composing = false;
      });
      listen(element, "input", (event) => {
        if (this.applying || !this.options.active() || this.options.trustedOnly && !event.isTrusted) return;
        if (this.pending && !this.matches(this.pending.command)) this.invalidate(this.pending.command.scope === "line" ? "Target line changed; rewrite cancelled. Finish the line and press Enter to retry." : "Command edited or undone; result cancelled.");
        if (this.composing || event.isComposing) return;
        if (event.inputType === "insertText" && event.data === "/" && editor.selectionStart === editor.selectionEnd) {
          const command = commandAt(editor.value, editor.selectionStart, "close");
          if (command) this.execute(command);
        }
      });
    }
    applying = false;
    composing = false;
    epoch = 0;
    pending;
    listeners = [];
    invalidate(message = "Pending command cancelled.") {
      this.epoch++;
      this.pending?.abort.abort();
      this.pending = void 0;
      this.options.status(message);
    }
    dispose() {
      this.invalidate();
      for (const { target, type, listener, capture } of this.listeners) target.removeEventListener(type, listener, capture);
      this.listeners = [];
    }
    matches(command) {
      const value = this.editor.value;
      return value.startsWith(command.prefix) && (command.scope !== "line" || command.end === value.length || value[command.end] === "\n");
    }
    key(event) {
      if (this.applying || !this.options.active() || !this.editor.isFocused() || this.options.trustedOnly && !event.isTrusted || this.composing || event.isComposing || event.keyCode === 229) return;
      if (event.key === "Escape" && this.pending) {
        event.preventDefault();
        event.stopImmediatePropagation();
        this.invalidate("Command cancelled. Original command kept.");
        return;
      }
      if (event.key !== "Enter" || event.shiftKey || event.ctrlKey || event.metaKey || event.altKey || this.editor.selectionStart !== this.editor.selectionEnd) return;
      if (this.pending) {
        event.preventDefault();
        event.stopImmediatePropagation();
        this.options.status("Command is still running. Shift+Enter inserts a newline; Escape cancels.");
        return;
      }
      const command = commandAt(this.editor.value, this.editor.selectionStart, "enter");
      if (!command) return;
      event.preventDefault();
      event.stopImmediatePropagation();
      this.execute(command, true);
    }
    execute(command, newline = false) {
      if (this.pending) {
        this.options.status("A command is already running. Keep typing, or Escape to cancel.");
        return;
      }
      if (!this.options.ready()) {
        this.options.status("Bridge not ready. Start or restart npm run cloud; command kept.");
        return;
      }
      if (command.lineText.length > 1600) {
        this.options.status("Keep a rewrite line under 1600 characters.");
        return;
      }
      if (command.instruction.length > 600) {
        this.options.status("Keep the instruction under 600 characters.");
        return;
      }
      if (!this.editor.canReplace(command.start, command.end)) {
        this.options.status("Command contains unsupported formatting or embedded content.");
        return;
      }
      if (newline) {
        this.applying = true;
        try {
          this.editor.insertText("\n", true);
        } finally {
          this.applying = false;
        }
      }
      const state = { abort: new AbortController(), command, epoch: this.epoch, caret: this.editor.selectionStart };
      this.pending = state;
      this.options.status(command.scope === "line" ? "Rewriting this line\u2026 editing it cancels. Other lines stay unchanged. Escape cancels." : "Running command\u2026 keep typing. Escape cancels.");
      void this.options.run(command, state.abort.signal).then((result) => {
        const caret = this.editor.selectionStart, selectionEnd = this.editor.selectionEnd, insideOriginal = command.scope === "line" && caret === selectionEnd && caret === state.caret;
        if (state.abort.signal.aborted || state.epoch !== this.epoch || !this.options.active() || this.composing || !this.editor.isFocused() || !this.matches(command) || !insideOriginal && (caret < command.end || selectionEnd < command.end)) {
          if (this.pending === state) this.options.status("Result discarded after editing, blur or selection change.");
          return;
        }
        if (typeof result.text !== "string" || !result.text.trim() || result.text.length > 2400) throw Error("Empty or oversized command response.");
        const value = this.editor.value, selection = { start: this.editor.selectionStart, end: this.editor.selectionEnd, direction: this.editor.selectionDirection }, delta = result.text.length - (command.end - command.start), scrollTop = this.editor.scrollTop, scrollLeft = this.editor.scrollLeft;
        const expected = value.slice(0, command.start) + result.text + value.slice(command.end);
        this.applying = true;
        try {
          this.editor.setSelectionRange(command.start, command.end);
          const applied = this.editor.insertText(result.text, true);
          if (applied && this.editor.value === expected) {
            if (selection.start < command.end) this.editor.setSelectionRange(command.start + result.text.length, command.start + result.text.length);
            else this.editor.setSelectionRange(selection.start + delta, selection.end + delta, selection.direction);
            this.options.status(`Inserted \xB7 ${result.model || "AI"}${result.totalMs !== void 0 ? " \xB7 " + Math.round(result.totalMs) + " ms" : ""} \xB7 Undo restores command`);
          } else if (this.editor.value === value) {
            this.editor.setSelectionRange(selection.start, selection.end, selection.direction);
            this.options.status("Editor rejected insertion. Command kept.");
          } else this.options.status("Host editor changed the insertion; result not confirmed.");
        } finally {
          this.applying = false;
          this.editor.scrollTop = scrollTop;
          this.editor.scrollLeft = scrollLeft;
        }
      }).catch((error) => {
        if (!state.abort.signal.aborted && state.epoch === this.epoch) this.options.status(String(error.message || error) + " Command kept.");
      }).finally(() => {
        if (this.pending === state) this.pending = void 0;
      });
    }
  };
  function commandTransport(send) {
    return async (command, signal) => {
      const requestId = crypto.randomUUID();
      const cancel = () => void send({ kind: "cancel", requestId }).catch(() => {
      });
      signal.addEventListener("abort", cancel, { once: true });
      try {
        const response = await send({ kind: "command", requestId, instruction: command.instruction, mode: command.mode, lineText: command.lineText, before: command.before, after: command.after });
        if (response.error) throw Error(response.error === "Not found" ? "Restart the updated bridge to enable inline commands." : response.error);
        if (response.commandStrategy !== "inline-commands-v2") throw Error("Restart the updated Brii bridge for inline commands.");
        return response;
      } finally {
        signal.removeEventListener("abort", cancel);
      }
    };
  }

  // src/brii/editor.ts
  var PlainEditor = class {
    constructor(element) {
      this.element = element;
    }
    get value() {
      return this.element.value;
    }
    get selectionStart() {
      return this.element.selectionStart ?? 0;
    }
    get selectionEnd() {
      return this.element.selectionEnd ?? 0;
    }
    get selectionDirection() {
      return this.element.selectionDirection ?? "none";
    }
    get scrollTop() {
      return this.element.scrollTop;
    }
    set scrollTop(value) {
      this.element.scrollTop = value;
    }
    get scrollLeft() {
      return this.element.scrollLeft;
    }
    set scrollLeft(value) {
      this.element.scrollLeft = value;
    }
    addEventListener(type, listener) {
      this.element.addEventListener(type, listener);
    }
    focus(options) {
      this.element.focus(options);
    }
    isFocused() {
      return document.activeElement === this.element;
    }
    setSelectionRange(start, end, direction = "none") {
      this.element.setSelectionRange(start, end, direction);
    }
    canReplace() {
      return true;
    }
    isAppend(previous, next, start, end) {
      return start === previous.length && end === previous.length && next.startsWith(previous);
    }
    atBoundary(position) {
      return position === this.value.length;
    }
    insertText(text) {
      return document.execCommand("insertText", false, text);
    }
  };
  var blocks = /* @__PURE__ */ new Set(["P", "DIV", "LI", "UL", "OL", "BLOCKQUOTE", "PRE", "H1", "H2", "H3", "H4", "H5", "H6"]);
  var RichSnapshot = class {
    constructor(root) {
      this.root = root;
      const emit = (value, before, after, text = false) => {
        const start = this.value.length;
        this.value += value;
        this.units.push({ start, end: this.value.length, before, after, text });
      };
      const walk = (node) => {
        const index = node.parentNode ? Array.prototype.indexOf.call(node.parentNode.childNodes, node) : 0;
        const before = { node: node.parentNode, offset: index }, after = { node: node.parentNode, offset: index + 1 };
        if (node instanceof Text) {
          const start2 = this.value.length;
          emit(node.data.replace(/\u00a0/g, " "), { node, offset: 0 }, { node, offset: node.length }, true);
          this.bounds.set(node, { start: start2, end: this.value.length });
          return;
        }
        if (!(node instanceof HTMLElement)) return;
        const block = node !== root && blocks.has(node.tagName);
        if (block && this.value && !this.value.endsWith("\n")) emit("\n", before, before);
        const start = this.value.length;
        if (node !== root && (node.contentEditable === "false" || node.matches('[data-private], [aria-readonly="true"], [hidden], [aria-hidden="true"]') || ["IMG", "HR", "INPUT", "TEXTAREA", "BUTTON", "IFRAME", "SCRIPT", "STYLE", "TEMPLATE"].includes(node.tagName))) emit("\uFFFC", before, after);
        else if (node.tagName === "BR") {
          if (node.nextSibling) emit("\n", before, after);
        } else for (const child of node.childNodes) walk(child);
        this.bounds.set(node, { start, end: this.value.length });
        if (block && (!this.value.endsWith("\n") || this.value.length === start)) emit("\n", after, after);
      };
      walk(root);
      const last = this.units.at(-1);
      if (last && !last.text && last.before.node === last.after.node && last.before.offset === last.after.offset) {
        this.value = this.value.slice(0, last.start);
        this.units.pop();
      }
    }
    value = "";
    units = [];
    bounds = /* @__PURE__ */ new Map();
    index(node, offset) {
      if (!node || !this.root.contains(node)) return;
      const bound = this.bounds.get(node);
      if (!bound) return;
      if (node instanceof Text) return Math.min(this.value.length, bound.start + Math.min(offset, node.length));
      if (offset < node.childNodes.length) {
        const next = this.bounds.get(node.childNodes[offset]);
        if (next) return Math.min(this.value.length, next.start);
      }
      return Math.min(this.value.length, bound.end);
    }
    point(index, end = false) {
      if (index < 0 || index > this.value.length) return;
      for (const [node, bound] of this.bounds) if (node instanceof HTMLElement && blocks.has(node.tagName) && bound.start === index && bound.end === index) return { node, offset: 0 };
      const list = end ? [...this.units].reverse() : this.units;
      for (const unit of list) if (unit.text && index >= unit.start && index <= unit.end) return { node: unit.before.node, offset: index - unit.start };
      for (const unit of list) if (index >= unit.start && index <= unit.end) return end ? unit.after : unit.before;
      if (!this.value) return { node: this.root, offset: 0 };
    }
    range(start, end) {
      const a = this.point(start), b = this.point(end, true);
      if (!a || !b) return;
      const range = document.createRange();
      range.setStart(a.node, a.offset);
      range.setEnd(b.node, b.offset);
      return range;
    }
  };
  var inlineTags = /* @__PURE__ */ new Set(["B", "STRONG", "I", "EM", "U", "S", "STRIKE", "DEL", "SPAN", "A", "CODE", "SUB", "SUP", "MARK", "SMALL"]);
  var styleProperties = ["font-weight", "font-style", "text-decoration", "text-decoration-line", "color", "background-color", "font-family", "font-size", "vertical-align", "white-space"];
  function safeFragment(fragment) {
    for (const element of fragment.querySelectorAll("*")) {
      if (!(element instanceof HTMLElement) || !inlineTags.has(element.tagName) || element.contentEditable === "false") return false;
      const styles = styleProperties.map((p) => [p, element.style.getPropertyValue(p)]).filter(([, v]) => v && !/url\s*\(|expression\s*\(/i.test(v));
      const href = element.tagName === "A" ? element.getAttribute("href") : null, title = element.getAttribute("title"), className = element.getAttribute("class"), direction = element.getAttribute("dir"), language = element.getAttribute("lang");
      for (const attr of [...element.attributes]) element.removeAttribute(attr.name);
      for (const [name, value] of styles) element.style.setProperty(name, value);
      if (href) {
        try {
          const url = new URL(href, document.baseURI);
          if (!["https:", "http:", "mailto:", "tel:"].includes(url.protocol)) return false;
          element.setAttribute("href", href);
        } catch {
          return false;
        }
      }
      if (title) element.setAttribute("title", title);
      if (className) element.setAttribute("class", className);
      if (direction && ["ltr", "rtl", "auto"].includes(direction)) element.setAttribute("dir", direction);
      if (language) element.setAttribute("lang", language);
    }
    return true;
  }
  function correctedBoundaries(source, target) {
    const width = target.length + 1, table = new Uint16Array((source.length + 1) * width);
    for (let i2 = 0; i2 <= source.length; i2++) table[i2 * width] = i2;
    for (let j2 = 0; j2 <= target.length; j2++) table[j2] = j2;
    for (let i2 = 1; i2 <= source.length; i2++) for (let j2 = 1; j2 <= target.length; j2++) table[i2 * width + j2] = Math.min(table[(i2 - 1) * width + j2] + 1, table[i2 * width + j2 - 1] + 1, table[(i2 - 1) * width + j2 - 1] + (source[i2 - 1] === target[j2 - 1] ? 0 : 1));
    const boundaries = new Array(source.length + 1);
    let i = source.length, j = target.length;
    boundaries[i] = j;
    while (i || j) {
      const cost = table[i * width + j];
      if (i && j && cost === table[(i - 1) * width + j - 1] + (source[i - 1] === target[j - 1] ? 0 : 1)) {
        i--;
        j--;
        boundaries[i] = j;
      } else if (j && cost === table[i * width + j - 1] + 1) {
        j--;
        boundaries[i] = j;
      } else {
        i--;
        boundaries[i] = j;
      }
    }
    boundaries[0] = 0;
    boundaries[source.length] = target.length;
    return boundaries;
  }
  var RichEditor = class {
    constructor(element) {
      this.element = element;
    }
    snapshot() {
      return new RichSnapshot(this.element);
    }
    get value() {
      return this.snapshot().value;
    }
    selection() {
      const snapshot = this.snapshot(), selection = document.getSelection();
      const anchor = snapshot.index(selection?.anchorNode ?? null, selection?.anchorOffset ?? 0), focus = snapshot.index(selection?.focusNode ?? null, selection?.focusOffset ?? 0);
      return anchor === void 0 || focus === void 0 ? void 0 : { start: Math.min(anchor, focus), end: Math.max(anchor, focus), direction: anchor > focus ? "backward" : anchor === focus ? "none" : "forward" };
    }
    get selectionStart() {
      return this.selection()?.start ?? -1;
    }
    get selectionEnd() {
      return this.selection()?.end ?? -1;
    }
    get selectionDirection() {
      return this.selection()?.direction ?? "none";
    }
    get scrollTop() {
      return this.element.scrollTop;
    }
    set scrollTop(value) {
      this.element.scrollTop = value;
    }
    get scrollLeft() {
      return this.element.scrollLeft;
    }
    set scrollLeft(value) {
      this.element.scrollLeft = value;
    }
    addEventListener(type, listener) {
      this.element.addEventListener(type, listener);
    }
    focus(options) {
      this.element.focus(options);
    }
    isFocused() {
      return document.activeElement === this.element && !!this.selection();
    }
    setSelectionRange(start, end, direction = "none") {
      const snapshot = this.snapshot(), a = snapshot.point(start), b = snapshot.point(end, true), selection = document.getSelection();
      if (!a || !b || !selection) throw Error("Editor selection changed; correction cancelled.");
      if (direction === "backward") selection.setBaseAndExtent(b.node, b.offset, a.node, a.offset);
      else selection.setBaseAndExtent(a.node, a.offset, b.node, b.offset);
    }
    isAppend(previous, next, start, end) {
      return start === end && (start === previous.length || previous[start] === "\n") && next.length >= previous.length && next.startsWith(previous.slice(0, start)) && next.endsWith(previous.slice(start));
    }
    atBoundary(position) {
      const value = this.value;
      return position === value.length || value[position] === "\n";
    }
    canReplace(start, end) {
      const snapshot = this.snapshot();
      if (/[\n\ufffc]/.test(snapshot.value.slice(start, end))) return false;
      const range = snapshot.range(start, end);
      return !!range && safeFragment(range.cloneContents());
    }
    insertText(text, multiline = false) {
      if (/[\r\n]/.test(text) && !multiline) return false;
      if (multiline && /[\r\n]/.test(text)) return document.execCommand("insertText", false, text);
      const selected = this.selection();
      if (!selected || !this.canReplace(selected.start, selected.end)) return false;
      const range = this.snapshot().range(selected.start, selected.end);
      const fragment = range.cloneContents();
      if (!safeFragment(fragment)) return false;
      if (!fragment.querySelector("*")) return document.execCommand("insertText", false, text);
      const walker = document.createTreeWalker(fragment, NodeFilter.SHOW_TEXT), nodes = [];
      while (walker.nextNode()) nodes.push(walker.currentNode);
      const source = nodes.map((n) => n.data.replace(/\u00a0/g, " ")).join(""), boundaries = correctedBoundaries(source, text);
      let at = 0;
      for (const node of nodes) {
        const end = at + node.length;
        node.data = text.slice(boundaries[at], boundaries[end]);
        at = end;
      }
      const container = document.createElement("div");
      container.append(fragment);
      return document.execCommand("insertHTML", false, container.innerHTML);
    }
  };

  // src/brii/cloud-client.ts
  var extensionTransport = (message) => chrome.runtime.sendMessage({ target: "briiCloud", ...message });

  // src/brii/cloud.ts
  var cloudDefaults = { enabled: false, automatic: true, sites: [], delay: 80 };
  var cloudSettings = async () => ({ ...cloudDefaults, ...(await chrome.storage.local.get("briiCloud")).briiCloud || {} });
  function cloudAllowed(url, s) {
    try {
      return s.enabled && s.sites.includes(new URL(url).origin);
    } catch {
      return false;
    }
  }
  function cloudFrameAllowed(url, origin, s) {
    if (url === "about:blank" || url === "about:srcdoc") return !!origin && cloudAllowed(origin, s);
    return cloudAllowed(url, s);
  }

  // src/shared.ts
  function safeField(el) {
    if (!(el instanceof HTMLTextAreaElement || el instanceof HTMLInputElement)) return false;
    if (el instanceof HTMLInputElement && !["text", "search"].includes(el.type)) return false;
    return !el.disabled && !el.readOnly && safeEditorMetadata(el);
  }
  function safeEditorMetadata(el) {
    return !el.closest('[data-private], [aria-readonly="true"], [aria-disabled="true"]') && !/password|one-time|cc-|username|email|tel|address|name|birth|transaction|ssn|social.?security|credit.?card|card.?number|cvv|bank|routing|api.?key|secret|token|otp/i.test(["autocomplete", "name", "id", "aria-label"].map((a) => el.getAttribute(a) || "").join(" "));
  }
  function richHost(el) {
    if (!(el instanceof HTMLElement) || !el.isContentEditable) return;
    let host = el;
    while (host.parentElement?.isContentEditable) host = host.parentElement;
    return safeEditorMetadata(host) ? host : void 0;
  }

  // src/flow-content.ts
  var global = globalThis;
  if (!global.__briiCommands) {
    let show = function(message) {
      if (!active()) {
        host.remove();
        return;
      }
      if (!host.isConnected) document.documentElement.append(host);
      status.textContent = "Brii \xB7 " + message;
    }, attach = function(target) {
      if (!active()) return;
      const element = safeField(target) ? target : richHost(target);
      if (!element) {
        if (target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement || target instanceof HTMLElement && target.isContentEditable) show("This field is excluded.");
        return;
      }
      show("Ready \xB7 //instruction// or //instruction then Enter");
      if (known.has(element)) return;
      for (const item of controllers) if (!item.element.isConnected) {
        item.flow.dispose();
        known.delete(item.element);
        controllers.delete(item);
      }
      known.add(element);
      const plain = safeField(element);
      const flow = new InlineCommands(plain ? new PlainEditor(element) : new RichEditor(element), element, { active: () => active() && (plain ? safeField(element) : richHost(element) === element), ready: active, trustedOnly: true, run: commandTransport(extensionTransport), status: show });
      controllers.add({ element, flow });
    };
    show2 = show, attach2 = attach;
    global.__briiCommands = true;
    let config;
    const controllers = /* @__PURE__ */ new Set(), known = /* @__PURE__ */ new WeakSet();
    const host = document.createElement("div");
    host.dataset.briiStatus = "";
    host.style.cssText = "position:fixed;right:12px;bottom:12px;z-index:2147483647;pointer-events:none;";
    const shadow = host.attachShadow({ mode: "closed" }), status = document.createElement("div");
    status.style.cssText = "font:12px/1.5 system-ui;background:#173a2b;color:white;padding:7px 12px;border-radius:5px;max-width:400px;";
    status.setAttribute("role", "status");
    shadow.append(status);
    const active = () => !!config && cloudFrameAllowed(location.href, globalThis.origin, config);
    document.addEventListener("focusin", (event) => {
      if (event.isTrusted) attach(event.target);
    }, true);
    void cloudSettings().then((settings) => {
      config = settings;
      attach(document.activeElement);
    });
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "local" && changes.briiCloud) {
        config = changes.briiCloud.newValue;
        for (const item of controllers) item.flow.invalidate("Command settings changed.");
        if (!active()) host.remove();
        else attach(document.activeElement);
      }
    });
    window.addEventListener("pagehide", () => {
      for (const item of controllers) item.flow.dispose();
      controllers.clear();
    });
  }
  var show2;
  var attach2;
})();
