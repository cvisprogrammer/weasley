// src/brii/commands.ts
function commandAt(value, caret, trigger) {
  if (caret < 0 || caret > value.length) return;
  if (trigger === "enter" && caret < value.length && value[caret] !== "\n") return;
  const lineStart = value.lastIndexOf("\n", caret - 1) + 1, line = value.slice(lineStart, caret);
  let found;
  for (let open = 0; open < line.length - 1; open++) {
    if (line.slice(open, open + 2) !== "//" || open > 0 && !/\s/.test(line[open - 1])) continue;
    let close = -1;
    for (let i = open + 2; i < line.length - 1; i++) if (line.slice(i, i + 2) === "//" && ![":", "\\"].includes(line[i - 1])) {
      close = i;
      break;
    }
    const end = close < 0 ? line.length : close + 2, instruction = line.slice(open + 2, close < 0 ? line.length : close).trim();
    if (instruction && (trigger === "enter" || close >= 0 && end === line.length)) {
      const markerStart = lineStart + open, markerEnd = lineStart + end, nextBreak = value.indexOf("\n", caret), lineEnd = nextBreak < 0 ? value.length : nextBreak;
      const lineText = value.slice(lineStart, markerStart) + value.slice(markerEnd, lineEnd), continuation = ["...", "\u2026"].includes(instruction), rewrite = !continuation && !!lineText.trim();
      const start = rewrite ? lineStart : markerStart, absoluteEnd = rewrite ? lineEnd : markerEnd;
      found = { start, end: absoluteEnd, instruction, mode: continuation ? "continue" : rewrite ? "rewrite-line" : "write", scope: rewrite ? "line" : "command", lineText: rewrite ? lineText : "", before: value.slice(Math.max(0, start - 1200), start), after: value.slice(absoluteEnd, absoluteEnd + 400), prefix: value.slice(0, absoluteEnd) };
    }
    if (close < 0) break;
    open = close + 1;
  }
  return found;
}
var InlineCommands = class {
  constructor(editor2, element, options) {
    this.editor = editor2;
    this.element = element;
    this.options = options;
    const listen = (target, type, fn, capture = false) => {
      target.addEventListener(type, fn, capture);
      this.listeners.push({ target, type, listener: fn, capture });
    };
    listen(document, "keydown", (e) => this.key(e), true);
    listen(element, "compositionstart", () => {
      this.composing = true;
      this.invalidate("Composition in progress; command paused.");
    });
    listen(element, "compositionend", () => {
      this.composing = false;
    });
    listen(element, "input", (event) => {
      if (this.applying || !this.options.active() || this.options.trustedOnly && !event.isTrusted) return;
      if (this.pending && !this.matches(this.pending.command)) this.invalidate(this.pending.command.scope === "line" ? "Target line changed; rewrite cancelled. Finish the line and press Enter to retry." : "Command edited or undone; result cancelled.");
      if (this.composing || event.isComposing) return;
      if (event.inputType === "insertText" && event.data === "/" && editor2.selectionStart === editor2.selectionEnd) {
        const command = commandAt(editor2.value, editor2.selectionStart, "close");
        if (command) this.execute(command);
      }
    });
  }
  applying = false;
  composing = false;
  epoch = 0;
  pending;
  listeners = [];
  invalidate(message = "Pending command cancelled.") {
    this.epoch++;
    this.pending?.abort.abort();
    this.pending = void 0;
    this.options.status(message);
  }
  dispose() {
    this.invalidate();
    for (const { target, type, listener, capture } of this.listeners) target.removeEventListener(type, listener, capture);
    this.listeners = [];
  }
  matches(command) {
    const value = this.editor.value;
    return value.startsWith(command.prefix) && (command.scope !== "line" || command.end === value.length || value[command.end] === "\n");
  }
  key(event) {
    if (this.applying || !this.options.active() || !this.editor.isFocused() || this.options.trustedOnly && !event.isTrusted || this.composing || event.isComposing || event.keyCode === 229) return;
    if (event.key === "Escape" && this.pending) {
      event.preventDefault();
      event.stopImmediatePropagation();
      this.invalidate("Command cancelled. Original command kept.");
      return;
    }
    if (event.key !== "Enter" || event.shiftKey || event.ctrlKey || event.metaKey || event.altKey || this.editor.selectionStart !== this.editor.selectionEnd) return;
    if (this.pending) {
      event.preventDefault();
      event.stopImmediatePropagation();
      this.options.status("Command is still running. Shift+Enter inserts a newline; Escape cancels.");
      return;
    }
    const command = commandAt(this.editor.value, this.editor.selectionStart, "enter");
    if (!command) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    this.execute(command, true);
  }
  execute(command, newline = false) {
    if (this.pending) {
      this.options.status("A command is already running. Keep typing, or Escape to cancel.");
      return;
    }
    if (!this.options.ready()) {
      this.options.status("Bridge not ready. Start or restart npm run cloud; command kept.");
      return;
    }
    if (command.lineText.length > 1600) {
      this.options.status("Keep a rewrite line under 1600 characters.");
      return;
    }
    if (command.instruction.length > 600) {
      this.options.status("Keep the instruction under 600 characters.");
      return;
    }
    if (!this.editor.canReplace(command.start, command.end)) {
      this.options.status("Command contains unsupported formatting or embedded content.");
      return;
    }
    const emailContext = this.options.context?.();
    if (emailContext) command = { ...command, emailContext };
    let newlineInserted = false;
    if (newline) {
      this.applying = true;
      try {
        newlineInserted = this.editor.insertText("\n", true);
      } finally {
        this.applying = false;
      }
    }
    const state = { abort: new AbortController(), command, epoch: this.epoch, caret: this.editor.selectionStart };
    this.pending = state;
    this.options.status((command.scope === "line" ? "Rewriting this line\u2026 editing it cancels. Other lines stay unchanged. Escape cancels." : "Running command\u2026 keep typing. Escape cancels.") + (emailContext ? " Using visible Gmail thread (" + emailContext.length + " characters)." : "") + (newline && !newlineInserted ? " Enter runs the command here; use Shift+Enter for a newline." : ""));
    void this.options.run(command, state.abort.signal).then(async (result) => {
      const caret = this.editor.selectionStart, selectionEnd = this.editor.selectionEnd, insideOriginal = command.scope === "line" && caret === selectionEnd && caret === state.caret;
      if (state.abort.signal.aborted || state.epoch !== this.epoch || !this.options.active() || this.composing || !this.editor.isFocused() || !this.matches(command) || !insideOriginal && (caret < command.end || selectionEnd < command.end)) {
        if (this.pending === state) this.options.status("Result discarded after editing, blur or selection change.");
        return;
      }
      if (typeof result.text !== "string" || !result.text.trim() || result.text.length > 2400) throw Error("Empty or oversized command response.");
      const insertionIssue = this.editor.insertionIssue?.(result.text);
      if (insertionIssue) throw Error(insertionIssue);
      const value = this.editor.value, selection = { start: this.editor.selectionStart, end: this.editor.selectionEnd, direction: this.editor.selectionDirection }, delta = result.text.length - (command.end - command.start), scrollTop = this.editor.scrollTop, scrollLeft = this.editor.scrollLeft;
      const expected = value.slice(0, command.start) + result.text + value.slice(command.end);
      this.applying = true;
      try {
        this.editor.setSelectionRange(command.start, command.end);
        this.editor.insertText(result.text, true);
        const commit = this.editor.settleInsertion?.();
        if (commit) await commit;
        if (this.editor.value === expected) {
          if (selection.start < command.end) this.editor.setSelectionRange(command.start + result.text.length, command.start + result.text.length);
          else this.editor.setSelectionRange(selection.start + delta, selection.end + delta, selection.direction);
          this.options.status(`Inserted \xB7 ${result.model || "AI"}${result.totalMs !== void 0 ? " \xB7 " + Math.round(result.totalMs) + " ms" : ""} \xB7 Undo restores command`);
        } else if (this.editor.value === value) {
          this.editor.setSelectionRange(selection.start, selection.end, selection.direction);
          this.options.status("Editor rejected insertion. Command kept.");
        } else this.options.status("Host editor changed the insertion; result not confirmed.");
      } finally {
        this.applying = false;
        this.editor.scrollTop = scrollTop;
        this.editor.scrollLeft = scrollLeft;
      }
    }).catch((error) => {
      if (!state.abort.signal.aborted && state.epoch === this.epoch) this.options.status(String(error.message || error) + " Command kept.");
    }).finally(() => {
      if (this.pending === state) this.pending = void 0;
    });
  }
};
function commandTransport(send2) {
  return async (command, signal) => {
    const requestId = crypto.randomUUID();
    const cancel = () => void send2({ kind: "cancel", requestId }).catch(() => {
    });
    signal.addEventListener("abort", cancel, { once: true });
    try {
      const response = await send2({ kind: "command", requestId, instruction: command.instruction, mode: command.mode, lineText: command.lineText, before: command.before, after: command.after, ...command.emailContext ? { emailContext: command.emailContext } : {} });
      if (response.error) throw Error(response.error === "Not found" ? "Restart the updated bridge to enable inline commands." : response.error);
      if (response.commandStrategy !== "inline-commands-v3") throw Error("Restart the updated Brii bridge for inline commands.");
      return response;
    } finally {
      signal.removeEventListener("abort", cancel);
    }
  };
}

// src/brii/editor.ts
var PlainEditor = class {
  constructor(element) {
    this.element = element;
  }
  get value() {
    return this.element.value;
  }
  get selectionStart() {
    return this.element.selectionStart ?? 0;
  }
  get selectionEnd() {
    return this.element.selectionEnd ?? 0;
  }
  get selectionDirection() {
    return this.element.selectionDirection ?? "none";
  }
  get scrollTop() {
    return this.element.scrollTop;
  }
  set scrollTop(value) {
    this.element.scrollTop = value;
  }
  get scrollLeft() {
    return this.element.scrollLeft;
  }
  set scrollLeft(value) {
    this.element.scrollLeft = value;
  }
  addEventListener(type, listener) {
    this.element.addEventListener(type, listener);
  }
  focus(options) {
    this.element.focus(options);
  }
  isFocused() {
    return document.activeElement === this.element;
  }
  setSelectionRange(start, end, direction = "none") {
    this.element.setSelectionRange(start, end, direction);
  }
  canReplace() {
    return true;
  }
  isAppend(previous, next, start, end) {
    return start === previous.length && end === previous.length && next.startsWith(previous);
  }
  atBoundary(position) {
    return position === this.value.length;
  }
  insertText(text) {
    return document.execCommand("insertText", false, text);
  }
};

// src/brii/cloud.ts
var cloudDefaults = { enabled: false, automatic: true, sites: [], delay: 80 };
var cloudSettings = async () => ({ ...cloudDefaults, ...(await chrome.storage.local.get("briiCloud")).briiCloud || {} });

// src/brii/cloud-client.ts
var extensionTransport = (message) => chrome.runtime.sendMessage({ target: "briiCloud", ...message });

// src/inline-playground.ts
var $ = (id) => document.getElementById(id);
var consent = $("consent");
var editor = $("editor");
var extension = location.protocol === "chrome-extension:";
var ready = false;
var extensionId = "";
var pending = /* @__PURE__ */ new Map();
var send = extension ? extensionTransport : async (message) => {
  if (message.kind === "cancel") {
    pending.get(message.requestId)?.abort();
    return { ok: true };
  }
  const health2 = message.kind === "health", abort = new AbortController();
  if (!health2) pending.set(message.requestId, abort);
  try {
    const response = await fetch(health2 ? "/health" : "/command", { method: health2 ? "GET" : "POST", headers: { "Content-Type": "application/json", "X-Brii-Extension": extensionId }, ...health2 ? {} : { body: JSON.stringify({ instruction: message.instruction, mode: message.mode, lineText: message.lineText || "", before: message.before, after: message.after }) }, signal: AbortSignal.any([abort.signal, AbortSignal.timeout(5e4)]), cache: "no-store" });
    const data = await response.json();
    return response.ok ? data : { error: data.error || "Command failed." };
  } finally {
    if (!health2) pending.delete(message.requestId);
  }
};
var flow = new InlineCommands(new PlainEditor(editor), editor, { active: () => consent.checked, ready: () => ready && consent.checked, run: commandTransport(send), status: (message) => {
  $("status").textContent = message;
} });
async function health() {
  try {
    const h = await send({ kind: "health" });
    extensionId = h.extensionId || "";
    ready = !!h.enabled && h.commands === true && h.commandStrategy === "inline-commands-v3";
    $("bridgeStatus").textContent = h.error || (h.commandStrategy !== "inline-commands-v3" ? "Update and restart the bridge for inline commands." : !h.enabled ? "Set OPENAI_API_KEY and restart the bridge." : `Ready \xB7 ${h.model} \xB7 inline commands`);
  } catch {
    ready = false;
    $("bridgeStatus").textContent = "Start npm run cloud in your terminal.";
  }
}
consent.onchange = async () => {
  flow.invalidate(consent.checked ? "Cloud commands enabled." : "Cloud commands off.");
  if (extension) {
    const settings = await cloudSettings();
    await chrome.storage.local.set({ briiCloud: { ...settings, enabled: consent.checked } });
  }
  await health();
};
if (extension) {
  void cloudSettings().then((settings) => {
    consent.checked = settings.enabled;
    void health();
  });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && changes.briiCloud) {
      consent.checked = !!changes.briiCloud.newValue?.enabled;
      flow.invalidate("Cloud settings changed.");
    }
  });
} else void health();
window.addEventListener("pagehide", () => flow.dispose());
