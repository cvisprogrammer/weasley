"use strict";
(() => {
  // src/shared.ts
  var modelId = "Qwen3.5-2B-q4f16_1-MLC";
  var defaults = { enabled: true, model: modelId, sites: [], delay: 250, tokens: 10 };
  var settings = async () => ({ ...defaults, ...(await chrome.storage.local.get("settings")).settings || {} });
  function allowed(url, s) {
    try {
      return s.enabled && s.sites.includes(new URL(url).origin);
    } catch {
      return false;
    }
  }
  function nextWord(text) {
    return text.match(/^\s*\S+\s*/)?.[0] || text;
  }
  function safeField(el) {
    if (!(el instanceof HTMLTextAreaElement || el instanceof HTMLInputElement)) return false;
    if (el instanceof HTMLInputElement && !["text", "search"].includes(el.type)) return false;
    return !el.disabled && !el.readOnly && !el.closest("[data-private]") && !/password|one-time|cc-|username|email|tel|address|name|birth|transaction|ssn|social.?security|credit.?card|card.?number|cvv|bank|routing|api.?key|secret|token|otp/i.test(el.autocomplete + " " + el.getAttribute("name") + " " + el.id + " " + el.getAttribute("aria-label"));
  }

  // src/content.ts
  var config;
  var composing = false;
  var epoch = 0;
  var suggestion = "";
  var snapshot = "";
  var cursor = 0;
  var pending = false;
  var field = null;
  var timer;
  var host = document.createElement("div");
  host.style.cssText = "position:fixed;inset:0;pointer-events:none;z-index:2147483647";
  var shadow = host.attachShadow({ mode: "closed" });
  var ghost = document.createElement("div");
  shadow.append(ghost);
  ghost.setAttribute("aria-hidden", "true");
  var send = (kind, data = {}) => chrome.runtime.sendMessage({ target: "background", kind, ...data }).catch(() => ({ text: "" }));
  var metric = (event, data = {}) => void send("metric", { event, ...data });
  function clear(reject = true) {
    clearTimeout(timer);
    epoch++;
    if (suggestion && reject) metric("rejected");
    suggestion = "";
    ghost.textContent = "";
    if (pending) {
      pending = false;
      void send("cancel");
    }
  }
  function paint() {
    if (!field || !suggestion) return;
    if (!host.isConnected) document.documentElement.append(host);
    const r = field.getBoundingClientRect(), s = getComputedStyle(field), mirror = document.createElement("div");
    for (const p2 of ["font", "letterSpacing", "lineHeight", "padding", "border", "boxSizing", "textIndent", "wordSpacing"]) mirror.style[p2] = s[p2];
    mirror.style.cssText += `;position:fixed;visibility:hidden;left:${r.left}px;top:${r.top}px;width:${r.width}px;white-space:${field instanceof HTMLTextAreaElement ? "pre-wrap" : "pre"};overflow-wrap:break-word;`;
    mirror.textContent = field.value.slice(0, cursor);
    const marker = document.createElement("span");
    marker.textContent = "\u200B";
    mirror.append(marker);
    shadow.append(mirror);
    const p = marker.getBoundingClientRect();
    mirror.remove();
    const x = p.left - field.scrollLeft, y = p.top - field.scrollTop;
    if (x < r.left || x > r.right - 8 || y < r.top || y > r.bottom - 8) {
      ghost.textContent = "";
      return;
    }
    ghost.style.cssText = `position:fixed;left:${x}px;top:${y}px;font:${s.font};letter-spacing:${s.letterSpacing};color:${s.color};opacity:.45;white-space:pre;max-width:${r.right - x - 8}px;overflow:hidden;`;
    ghost.textContent = suggestion;
  }
  async function schedule() {
    clear();
    if (!config || !allowed(location.href, config) || composing || !safeField(document.activeElement)) return;
    field = document.activeElement;
    if (field.selectionStart !== field.selectionEnd || field.selectionStart !== field.value.length || field.value.length < 3) return;
    snapshot = field.value;
    cursor = field.selectionStart;
    const ticket = epoch, target = field;
    timer = setTimeout(async () => {
      pending = true;
      const r = await send("predict", { prefix: snapshot.slice(-1800) });
      if (ticket === epoch) pending = false;
      if (ticket !== epoch || composing || document.activeElement !== target || target.value !== snapshot || target.selectionStart !== cursor || !config.enabled) return;
      if (r.text) {
        suggestion = r.text;
        paint();
        metric("shown", { chars: suggestion.length, ttft: r.ttft, total: r.total });
      }
    }, config.delay);
  }
  document.addEventListener("input", () => void schedule(), true);
  document.addEventListener("compositionstart", () => {
    composing = true;
    clear();
  }, true);
  document.addEventListener("compositionend", () => {
    composing = false;
    void schedule();
  }, true);
  for (const event of ["focusout", "pointerdown", "scroll"]) document.addEventListener(event, () => clear(), true);
  window.addEventListener("resize", () => clear());
  document.addEventListener("keydown", (e) => {
    if (composing || e.isComposing) return;
    if (e.key === "Escape") {
      clear();
      return;
    }
    if (suggestion && field && document.activeElement === field && field.value === snapshot && field.selectionStart === cursor && field.selectionEnd === cursor && (e.key === "Tab" && !e.shiftKey && !e.ctrlKey && !e.altKey && !e.metaKey || e.key === "ArrowRight" && e.altKey && !e.shiftKey && !e.ctrlKey && !e.metaKey)) {
      const text = e.altKey ? nextWord(suggestion) : suggestion;
      e.preventDefault();
      e.stopImmediatePropagation();
      clear(false);
      if (document.execCommand("insertText", false, text)) {
        metric("accepted", { chars: text.length, keys: e.altKey ? 2 : 1 });
        void schedule();
      }
      return;
    }
    if (!["Shift", "Control", "Alt", "Meta"].includes(e.key)) clear();
  }, true);
  void settings().then((s) => config = s);
  chrome.storage.onChanged.addListener((c, a) => {
    if (a === "local" && c.settings) {
      config = c.settings.newValue;
      clear();
    }
  });
})();
