// src/shared.ts
var modelId = "Qwen3.5-2B-q4f16_1-MLC";
var defaults = { enabled: true, model: modelId, sites: [], delay: 250, maxWords: 3 };
var settings = async () => ({ ...defaults, ...(await chrome.storage.local.get("settings")).settings || {} });
function allowed(url, s) {
  try {
    return s.enabled && s.sites.includes(new URL(url).origin);
  } catch {
    return false;
  }
}
function matchPattern(origin) {
  const u = new URL(origin);
  return `${u.protocol}//${u.hostname}/*`;
}

// src/background.ts
var creating;
var metricQueue = Promise.resolve();
async function ensure() {
  if (await chrome.offscreen.hasDocument()) return;
  if (!creating) creating = chrome.offscreen.createDocument({ url: "offscreen.html", reasons: [chrome.offscreen.Reason.WORKERS], justification: "Run a shared, local WebGPU model in a dedicated worker without blocking typing." }).finally(() => {
    creating = void 0;
  });
  await creating;
}
async function register() {
  await chrome.scripting.unregisterContentScripts();
  const s = await settings();
  const matches = [];
  for (const origin of s.sites) if (await chrome.permissions.contains({ origins: [matchPattern(origin)] })) matches.push(matchPattern(origin));
  if (matches.length) await chrome.scripting.registerContentScripts([{ id: "typing", matches: [...new Set(matches)], js: ["content.js"], runAt: "document_idle", persistAcrossSessions: true }]);
}
var registration = Promise.resolve();
function queueRegister() {
  registration = registration.catch(() => {
  }).then(register);
}
chrome.runtime.onInstalled.addListener(queueRegister);
chrome.runtime.onStartup.addListener(queueRegister);
chrome.storage.onChanged.addListener((c, area) => {
  if (area === "local" && c.settings && JSON.stringify(c.settings.oldValue?.sites) !== JSON.stringify(c.settings.newValue?.sites)) queueRegister();
});
chrome.runtime.onMessage.addListener((m, sender, reply) => {
  if (sender.id !== chrome.runtime.id || m.target !== "background") return;
  void (async () => {
    try {
      const s = await settings();
      const lab = sender.url === chrome.runtime.getURL("test.html");
      const popup = sender.url === chrome.runtime.getURL("popup.html");
      const pageCommand = ["predict", "cancel", "metric"].includes(m.kind);
      if (lab) {
        if (!s.enabled || !pageCommand) {
          reply({ text: "", error: "Enable Weasley to use the test page." });
          return;
        }
      } else if (sender.tab) {
        if (!allowed(sender.url || "", s) || !pageCommand) {
          reply({ text: "", error: "This website is not enabled in Weasley." });
          return;
        }
      } else if (!popup) {
        reply({ text: "", error: "Unauthorized" });
        return;
      }
      if (m.kind === "metric") {
        metricQueue = metricQueue.catch(() => {
        }).then(async () => {
          const metrics = (await chrome.storage.local.get("metrics")).metrics || [];
          const event = { at: Date.now(), kind: ["shown", "accepted", "rejected"].includes(m.event) ? m.event : "shown", keys: Math.max(1, Math.min(2, Number(m.keys) || 1)), chars: Math.max(0, Number(m.chars) || 0), ttft: Math.max(0, Number(m.ttft) || 0), total: Math.max(0, Number(m.total) || 0) };
          await chrome.storage.local.set({ metrics: [...metrics.slice(-499), event] });
        });
        await metricQueue;
        reply({});
        return;
      }
      if (m.kind === "predict" && (typeof m.prefix !== "string" || m.prefix.length > 1800 || typeof m.context !== "string" || m.context.length > 1200)) {
        reply({ text: "", error: "Prediction request exceeds the supported text/context size." });
        return;
      }
      if (m.kind === "resetEngine") {
        if (await chrome.offscreen.hasDocument()) await chrome.offscreen.closeDocument();
        reply({ ok: true });
        return;
      }
      await ensure();
      reply(await chrome.runtime.sendMessage({ ...m, settings: s, owner: sender.tab?.id ?? (lab ? sender.documentId || "lab" : "popup"), target: "engine" }));
    } catch (e) {
      reply({ error: String(e), text: "" });
    }
  })();
  return true;
});
