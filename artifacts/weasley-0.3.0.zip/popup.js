// src/shared.ts
var modelId = "Qwen3.5-2B-q4f16_1-MLC";
var defaults = { enabled: true, model: modelId, sites: [], delay: 250, maxWords: 3 };
var settings = async () => ({ ...defaults, ...(await chrome.storage.local.get("settings")).settings || {} });
function matchPattern(origin) {
  const u = new URL(origin);
  return `${u.protocol}//${u.hostname}/*`;
}

// src/popup.ts
var $ = (id) => document.getElementById(id);
var input = (id) => $(id);
var s = await settings();
var save = () => chrome.storage.local.set({ settings: s });
input("enabled").checked = s.enabled;
for (const k of ["model", "delay", "maxWords"]) input(k).value = String(s[k]);
input("enabled").onchange = () => {
  s.enabled = input("enabled").checked;
  void save();
};
input("model").onchange = () => {
  s.model = input("model").value;
  void save();
};
input("delay").onchange = () => {
  s.delay = Math.max(100, Math.min(2e3, Number(input("delay").value) || 250));
  void save();
};
function render() {
  $("sites").replaceChildren();
  for (const origin of s.sites) {
    const li = document.createElement("li");
    li.textContent = origin + " ";
    const b = document.createElement("button");
    b.textContent = "Remove";
    b.onclick = async () => {
      s.sites = s.sites.filter((x) => x !== origin);
      await save();
      if (!s.sites.some((x) => matchPattern(x) === matchPattern(origin))) await chrome.permissions.remove({ origins: [matchPattern(origin)] });
      render();
    };
    li.append(b);
    $("sites").append(li);
  }
}
render();
$("add").onclick = async () => {
  try {
    const u = new URL(input("site").value);
    if (!["http:", "https:"].includes(u.protocol)) throw Error("Use http or https");
    const origin = u.origin;
    if (await chrome.permissions.request({ origins: [matchPattern(origin)] })) {
      s.sites = [.../* @__PURE__ */ new Set([...s.sites, origin])];
      await save();
      render();
    }
  } catch (e) {
    $("status").textContent = String(e);
  }
};
var send = (kind) => chrome.runtime.sendMessage({ target: "background", kind });
$("resetEngine").onclick = async () => {
  await send("resetEngine");
  await refresh();
};
$("load").onclick = async () => {
  const b = $("load");
  b.disabled = true;
  try {
    const r = await send("load");
    $("status").textContent = r.error || "Ready";
  } catch (e) {
    $("status").textContent = String(e);
  } finally {
    b.disabled = false;
  }
};
async function refresh() {
  void pageContext("contextStatus");
  try {
    const state = await send("status");
    $("status").textContent = state.text || state.error;
    const metrics = (await chrome.storage.local.get("metrics")).metrics || [];
    const shown = metrics.filter((x) => x.kind === "shown"), accepted = metrics.filter((x) => x.kind === "accepted"), rejected = metrics.filter((x) => x.kind === "rejected");
    const avg = (k) => shown.length ? Math.round(shown.reduce((a, x) => a + x[k], 0) / shown.length) : 0;
    $("stats").textContent = `Last 500 events
Shown: ${shown.length} \xB7 Accepted: ${accepted.length}
Acceptance: ${shown.length ? (100 * accepted.length / shown.length).toFixed(1) : 0}%
Rejected: ${rejected.length}
Mean TTFT: ${avg("ttft")} ms
Mean completion: ${avg("total")} ms
Mean length: ${avg("chars")} chars
Accepted characters: ${accepted.reduce((a, x) => a + x.chars, 0)}
Estimated net keys saved: ${accepted.reduce((a, x) => a + Math.max(0, x.chars - (x.keys || 1)), 0)}`;
  } catch (e) {
    $("status").textContent = String(e);
  }
}
$("reset").onclick = async () => {
  await chrome.storage.local.remove("metrics");
  await refresh();
};
void refresh();
setInterval(() => void refresh(), 1500);
$("try").onclick = () => void chrome.tabs.create({ url: chrome.runtime.getURL("test.html") });
input("maxWords").onchange = () => {
  s.maxWords = Number(input("maxWords").value);
  void save();
};
async function pageContext(kind) {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) throw Error("No active page");
    let r;
    try {
      r = await chrome.tabs.sendMessage(tab.id, { kind });
    } catch {
      r = await chrome.runtime.sendMessage({ target: "lab", kind, labTabId: tab.id });
    }
    $("contextPreview").textContent = r.context ? `${r.characters}/1200 characters
${r.context}` : "No relevant context collected yet.";
    $("pageStatus").textContent = r.error || r.status || "";
  } catch {
    $("pageStatus").textContent = "Click Try it for the built-in test, or reload an allowed website.";
  }
}
void pageContext("contextStatus");
