// src/brii/result-view.ts
function resultLabel(result) {
  return `${result.applied ? "Suggestion applied" : result.unchanged ? "No visible change" : "Suggestion not applied"} \xB7 ${Math.round(result.result.totalMs)} ms \xB7 quality unverified${result.unprocessedTail ? " \xB7 newer typing not included" : ""}`;
}
function resultView() {
  const element = document.createElement("details"), summary = document.createElement("summary"), body = document.createElement("div");
  element.hidden = true;
  element.style.cssText = "pointer-events:auto;font:12px/1.5 system-ui;background:#f7faf7;color:#24332e;border:1px solid #b9c6bc;border-radius:5px;margin-top:4px;padding:6px 10px;max-width:min(400px,calc(100vw - 48px));";
  summary.textContent = "Last result";
  summary.style.cursor = "pointer";
  body.style.cssText = "max-height:40vh;overflow:auto;";
  element.append(summary, body);
  return { element, clear() {
    element.hidden = true;
    element.open = false;
    body.replaceChildren();
    summary.textContent = "Last result";
  }, update(result) {
    summary.textContent = "Last result \xB7 " + (result.applied ? "suggestion applied" : result.unchanged ? "no visible change" : "not applied");
    body.replaceChildren();
    const info = document.createElement("p");
    info.textContent = `${result.result.model || "Model not reported"} \xB7 ${result.result.strategy || "strategy not reported"} \xB7 ${resultLabel(result)}. \u201CApplied\u201D does not mean correct. ${result.reason}`;
    body.append(info);
    const coverage = document.createElement("p");
    coverage.textContent = `Editor range ${result.segment.start}\u2013${result.segment.end}. Protected edits in this range: ${(result.segment.protectedRanges || []).map((r) => r.start + "\u2013" + r.end).join(", ") || "none"}.`;
    body.append(coverage);
    const rows = [["Original typing sent", result.segment.raw], ["Current draft before request", result.segment.prefix.slice(result.segment.start, result.segment.end)], ["Context sent", result.segment.context], ["Model response", result.result.corrected]];
    for (const [label, text] of rows) {
      const heading = document.createElement("strong"), value = document.createElement("pre");
      heading.textContent = label;
      value.textContent = text || "(empty)";
      value.style.cssText = "white-space:pre-wrap;overflow-wrap:anywhere;margin:3px 0 10px;";
      body.append(heading, value);
    }
    element.hidden = false;
  } };
}

// src/brii/input-change.ts
function inputChange(previous, value, before, selection, history, isAppend) {
  if (history) return "history";
  if (value === previous) return "unchanged";
  if (!previous.trim()) return "append";
  if (!value || before?.start === 0 && before.end === previous.length) return "restart";
  const replacedSelection = !!before && before.start >= 0 && before.end > before.start && before.end <= previous.length;
  const added = value.length - previous.length, start = selection.start - added;
  if (!replacedSelection && added > 0 && selection.start === selection.end && start >= 0 && start <= previous.length && isAppend(start, start)) return "append";
  return "edit";
}

// src/brii/editor.ts
var PlainEditor = class {
  constructor(element) {
    this.element = element;
  }
  get value() {
    return this.element.value;
  }
  get selectionStart() {
    return this.element.selectionStart ?? 0;
  }
  get selectionEnd() {
    return this.element.selectionEnd ?? 0;
  }
  get selectionDirection() {
    return this.element.selectionDirection ?? "none";
  }
  get scrollTop() {
    return this.element.scrollTop;
  }
  set scrollTop(value) {
    this.element.scrollTop = value;
  }
  get scrollLeft() {
    return this.element.scrollLeft;
  }
  set scrollLeft(value) {
    this.element.scrollLeft = value;
  }
  addEventListener(type, listener) {
    this.element.addEventListener(type, listener);
  }
  focus(options) {
    this.element.focus(options);
  }
  isFocused() {
    return document.activeElement === this.element;
  }
  setSelectionRange(start, end, direction = "none") {
    this.element.setSelectionRange(start, end, direction);
  }
  canReplace() {
    return true;
  }
  isAppend(previous, next, start, end) {
    return start === previous.length && end === previous.length && next.startsWith(previous);
  }
  atBoundary(position) {
    return position === this.value.length;
  }
  insertText(text) {
    return document.execCommand("insertText", false, text);
  }
};

// src/brii/decoding.ts
var MAX_SEGMENT = 600;
function sentenceStart(value, end) {
  const prefix = value.slice(0, end), trimmedEnd = prefix.trimEnd().length;
  let start = prefix.lastIndexOf("\n") + 1;
  for (const match of prefix.matchAll(/[.!?]["')\]]*\s+/g)) {
    const after = match.index + match[0].length;
    if (after <= trimmedEnd) start = Math.max(start, after);
  }
  return start;
}
function segmentAt(value, end, frontier, manual = false) {
  if (end < 0 || end > value.length || !manual && !/\s$/.test(value.slice(0, end))) return;
  let start = manual ? sentenceStart(value, end) : Math.min(frontier, end);
  while (start < end && /\s/.test(value[start])) start++;
  const raw = value.slice(start, end).trimEnd();
  if (!raw.trim()) return;
  if (raw.length > MAX_SEGMENT) throw Error(`Correction chunk exceeds ${MAX_SEGMENT} characters. Use shorter bursts or place the caret in a shorter sentence and use manual correction.`);
  return { start, end: start + raw.length, raw, context: value.slice(Math.max(0, start - 400), start), prefix: value.slice(0, start + raw.length) };
}
function planReplacement(segment, corrected, current, selection) {
  if (!current.startsWith(segment.prefix) || selection.start < segment.end || selection.end < segment.end) return;
  const delta = corrected.length - (segment.end - segment.start);
  return { start: segment.start, end: segment.end, text: corrected, delta, selection: { ...selection, start: selection.start + delta, end: selection.end + delta } };
}

// src/brii/rolling.ts
function rawBoundaries(raw, text) {
  const width = text.length + 1, table = new Uint16Array((raw.length + 1) * width);
  for (let i2 = 0; i2 <= raw.length; i2++) table[i2 * width] = i2;
  for (let j2 = 0; j2 <= text.length; j2++) table[j2] = j2;
  for (let i2 = 1; i2 <= raw.length; i2++) for (let j2 = 1; j2 <= text.length; j2++) table[i2 * width + j2] = Math.min(table[(i2 - 1) * width + j2] + 1, table[i2 * width + j2 - 1] + 1, table[(i2 - 1) * width + j2 - 1] + (raw[i2 - 1] === text[j2 - 1] ? 0 : 1));
  const boundary = new Array(width);
  let i = raw.length, j = text.length;
  boundary[j] = i;
  while (i || j) {
    const cost = table[i * width + j];
    if (i && j && cost === table[(i - 1) * width + j - 1] + (raw[i - 1] === text[j - 1] ? 0 : 1)) {
      i--;
      j--;
      boundary[j] = i;
    } else if (i && cost === table[(i - 1) * width + j] + 1) {
      i--;
      boundary[j] = i;
    } else {
      j--;
      boundary[j] = i;
    }
  }
  boundary[0] = 0;
  boundary[text.length] = raw.length;
  return boundary;
}
var RollingDraft = class {
  revisions = [];
  protectedRanges = [];
  reset() {
    this.revisions = [];
    this.protectedRanges = [];
  }
  protect(end) {
    this.reset();
    if (end > 0) this.protectedRanges = [{ start: 0, end }];
  }
  edited(previous, value, history = false) {
    let start = 0;
    while (start < previous.length && start < value.length && previous[start] === value[start]) start++;
    let oldEnd = previous.length, newEnd = value.length;
    while (oldEnd > start && newEnd > start && previous[oldEnd - 1] === value[newEnd - 1]) {
      oldEnd--;
      newEnd--;
    }
    const delta = newEnd - oldEnd;
    let oldFrom = start, oldTo = oldEnd;
    while (oldFrom > 0 && /\S/.test(previous[oldFrom - 1])) oldFrom--;
    while (oldTo < previous.length && /\S/.test(previous[oldTo])) oldTo++;
    const overlaps = (r) => start === oldEnd ? r.start < start && r.end > start : r.start < oldEnd && r.end > start;
    const reconstructed = this.revisions.some((r) => r.end > oldFrom && r.start < oldTo && r.raw !== previous.slice(r.start, r.end));
    const deliberate = history || reconstructed || this.protectedRanges.some(overlaps);
    this.revisions = this.revisions.filter((r) => r.end <= oldFrom || r.start >= oldTo).map((r) => r.start >= oldEnd ? { ...r, start: r.start + delta, end: r.end + delta } : r);
    this.protectedRanges = this.protectedRanges.flatMap((r) => r.end <= start ? [r] : r.start >= oldEnd ? [{ start: r.start + delta, end: r.end + delta }] : []);
    if (deliberate) {
      let from = start, to = newEnd;
      while (from > 0 && /\S/.test(value[from - 1])) from--;
      while (to < value.length && /\S/.test(value[to])) to++;
      if (to > from) this.protectedRanges.push({ start: from, end: to });
    }
    this.protectedRanges.sort((a, b) => a.start - b.start);
    this.protectedRanges = this.protectedRanges.reduce((ranges, r) => {
      const last2 = ranges.at(-1);
      if (last2 && r.start <= last2.end) last2.end = Math.max(last2.end, r.end);
      else ranges.push({ ...r });
      return ranges;
    }, []);
  }
  segment(value, boundary, wholeSentence = false, manual = false) {
    let start = sentenceStart(value, boundary);
    const end = value.slice(0, boundary).trimEnd().length;
    if (end <= start) return;
    if (!wholeSentence) {
      const words = [...value.slice(start, end).matchAll(/\S+/g)];
      if (words.length > 12) start += words[words.length - 12].index;
    }
    for (const revision of this.revisions) if (revision.start < start && revision.end > start) start = revision.start;
    while (start < end && /\s/.test(value[start])) start++;
    const shown = value.slice(start, end);
    if (!shown.trim()) return;
    let raw = "", at = start;
    for (const revision of this.revisions) {
      if (revision.start < start || revision.end > end) continue;
      raw += value.slice(at, revision.start) + revision.raw;
      at = revision.end;
    }
    raw += value.slice(at, end);
    if (raw.length > MAX_SEGMENT || shown.length > MAX_SEGMENT) throw Error(`Correction chunk exceeds ${MAX_SEGMENT} characters. Finish this sentence before continuing.`);
    return { start, end, raw, context: value.slice(Math.max(0, start - 400), start), prefix: value.slice(0, end), protectedRanges: this.protectedRanges.filter((r) => r.end > start && r.start < end).map((r) => ({ ...r })) };
  }
  canApply(segment, text) {
    if (!segment.protectedRanges?.length) return true;
    const shown = segment.prefix.slice(segment.start, segment.end);
    if (text === shown) return true;
    const boundaries = rawBoundaries(text, shown);
    return (segment.protectedRanges || []).every((r) => {
      const start = Math.max(r.start, segment.start) - segment.start, end = Math.min(r.end, segment.end) - segment.start;
      return text.slice(boundaries[start], boundaries[end]) === shown.slice(start, end);
    });
  }
  applied(segment, text, manual = false) {
    const delta = text.length - (segment.end - segment.start), mapped = rawBoundaries(text, segment.prefix.slice(segment.start, segment.end));
    this.protectedRanges = this.protectedRanges.flatMap((r) => {
      if (r.end <= segment.start) return [r];
      if (r.start >= segment.end) return [{ start: r.start + delta, end: r.end + delta }];
      if (manual) return [...r.start < segment.start ? [{ start: r.start, end: segment.start }] : [], ...r.end > segment.end ? [{ start: segment.start + text.length, end: r.end + delta }] : []];
      return [{ start: r.start < segment.start ? r.start : segment.start + mapped[r.start - segment.start], end: r.end > segment.end ? r.end + delta : segment.start + mapped[r.end - segment.start] }];
    });
    this.revisions = this.revisions.filter((r) => r.end <= segment.start || r.start >= segment.end).map((r) => r.start >= segment.end ? { ...r, start: r.start + delta, end: r.end + delta } : r);
    const boundaries = rawBoundaries(segment.raw, text);
    for (const word of text.matchAll(/\S+|\s+/g)) {
      const start = word.index, end = start + word[0].length;
      this.revisions.push({ start: segment.start + start, end: segment.start + end, raw: segment.raw.slice(boundaries[start], boundaries[end]) });
    }
    this.revisions.sort((a, b) => a.start - b.start);
  }
};

// src/brii/flow.ts
var BriiFlow = class {
  constructor(editor, options) {
    this.options = options;
    this.editor = editor instanceof HTMLTextAreaElement || editor instanceof HTMLInputElement ? new PlainEditor(editor) : editor;
    this.previous = this.editor.value;
    const remember = (event) => {
      if (!this.applying && this.active() && (!this.options.trustedOnly || event.isTrusted)) this.before = { start: this.editor.selectionStart, end: this.editor.selectionEnd };
    };
    this.editor.addEventListener("beforeinput", remember);
    this.editor.addEventListener("paste", remember);
    this.editor.addEventListener("cut", remember);
    this.editor.addEventListener("input", (e) => this.input(e));
    this.editor.addEventListener("compositionstart", () => {
      this.composing = true;
      if (this.active()) {
        this.compositionBefore = { start: this.editor.selectionStart, end: this.editor.selectionEnd };
        this.before = void 0;
        this.invalidate("IME composition: correction paused.");
      }
    });
    this.editor.addEventListener("compositionend", (event) => {
      this.composing = false;
      if (this.active()) {
        this.before = this.compositionBefore;
        this.compositionBefore = void 0;
        this.input({ isTrusted: event.isTrusted, inputType: "insertCompositionText", data: event.data, isComposing: false });
      }
    });
    this.editor.addEventListener("keydown", (e) => {
      remember(e);
      if (this.active() && (!this.options.trustedOnly || e.isTrusted) && (e.ctrlKey || e.metaKey) && e.key === "Enter" && !e.isComposing) {
        e.preventDefault();
        this.manual();
      }
    });
  }
  draft = new RollingDraft();
  pauseTimer;
  epoch = 0;
  frontier = 0;
  pending = false;
  applying = false;
  composing = false;
  previous;
  before;
  compositionBefore;
  queued;
  timer;
  editor;
  active() {
    return this.options.active?.() ?? true;
  }
  get isBusy() {
    return this.pending;
  }
  invalidate(message = "Pending corrections cancelled.") {
    clearTimeout(this.pauseTimer);
    this.epoch++;
    this.queued = void 0;
    clearTimeout(this.timer);
    if (this.active()) {
      this.frontier = sentenceStart(this.editor.value, this.editor.selectionStart);
      this.previous = this.editor.value;
    } else {
      this.frontier = 0;
      this.previous = "";
      this.draft.reset();
    }
    if (this.pending) this.options.cancel();
    this.options.status(message);
  }
  manual() {
    if (this.composing || !this.active()) return;
    this.editor.focus({ preventScroll: true });
    if (this.editor.selectionStart !== this.editor.selectionEnd) {
      this.options.status("Collapse the selection first. Selected text is never overwritten.");
      return;
    }
    this.enqueue(this.editor.selectionStart, true);
  }
  input(event) {
    if (this.applying || !this.active() || this.options.trustedOnly && !event.isTrusted) return;
    const value = this.editor.value;
    const history = event.inputType === "historyUndo" || event.inputType === "historyRedo";
    if (this.composing || event.isComposing) {
      clearTimeout(this.pauseTimer);
      this.before = void 0;
      return;
    }
    const change = inputChange(this.previous, value, this.before, { start: this.editor.selectionStart, end: this.editor.selectionEnd }, history, (start, end) => this.editor.isAppend(this.previous, value, start, end));
    this.before = void 0;
    if (change === "unchanged") return;
    clearTimeout(this.pauseTimer);
    const appendOnly = change === "append" || change === "restart";
    if (change === "restart") {
      this.invalidate("New draft started.");
      this.draft.reset();
    }
    if (this.options.rolling && (change === "history" || change === "edit")) this.draft.edited(this.previous, value, history);
    if (change === "history" || change === "edit") this.invalidate(history ? "Undo/redo preserved. Type another Space to resume." : "Edit invalidated the previous correction.");
    this.previous = value;
    if (this.composing || event.isComposing || history) return;
    if (this.options.rolling && !this.pending) this.options.status(this.options.automatic() ? "New typing is unprocessed. Press Space or Cmd/Ctrl+Enter to decode." : "New typing is unprocessed. Press Cmd/Ctrl+Enter to decode.");
    if (this.options.automatic() && event.inputType === "insertText" && event.data === " " && this.editor.selectionStart === this.editor.selectionEnd) this.enqueue(this.editor.selectionStart, false);
    if (this.options.rolling && this.options.automatic() && event.inputType === "insertText" && appendOnly) {
      const epoch = this.epoch;
      this.pauseTimer = setTimeout(() => {
        if (epoch !== this.epoch || !this.active() || !this.options.automatic() || !this.editor.atBoundary(this.editor.selectionStart) || this.editor.selectionEnd !== this.editor.selectionStart) return;
        const boundary = this.editor.selectionStart, prefix = this.editor.value.slice(0, boundary);
        const completed = /[.!?]$/.test(prefix) ? boundary : prefix.search(/\S*$/);
        if (completed > 0) this.enqueue(completed, false, true);
      }, 650);
    }
  }
  enqueue(boundary, manual, wholeSentence = false) {
    if (!this.options.ready()) {
      this.options.status("Decoder is not ready. Check the connection or model; raw typing continues normally.");
      return;
    }
    const at = performance.now();
    this.queued = { boundary, manual, wholeSentence, epoch: this.epoch, due: at + (manual ? 0 : this.options.delay()), at };
    this.options.status(this.pending ? "Queued the latest completed text; current inference continues." : "Waiting for the short Space debounce\u2026");
    this.drain();
  }
  drain() {
    clearTimeout(this.timer);
    if (this.pending || !this.queued || this.composing) return;
    const wait = this.queued.due - performance.now();
    if (wait > 0) {
      this.timer = setTimeout(() => this.drain(), wait);
      return;
    }
    const queued = this.queued;
    this.queued = void 0;
    if (!this.options.ready() || queued.epoch !== this.epoch || !queued.manual && !this.options.automatic() || !this.editor.isFocused() || this.editor.selectionStart < queued.boundary) {
      this.options.status("Queued correction skipped after focus, selection, model, or mode changed.");
      return;
    }
    let segment;
    try {
      segment = this.options.rolling ? this.draft.segment(this.editor.value, queued.boundary, queued.wholeSentence || queued.manual, queued.manual) : segmentAt(this.editor.value, queued.boundary, this.frontier, queued.manual);
    } catch (e) {
      this.options.status(String(e));
      return;
    }
    if (!segment) return;
    if (!this.editor.canReplace(segment.start, segment.end)) {
      this.options.status("This range contains unsupported formatting or embedded content; original text preserved.");
      return;
    }
    const started = queued.at;
    this.pending = true;
    this.options.status(this.options.decodingStatus || "Decoding locally\u2026 keep typing.");
    void this.options.decode(segment.raw, segment.context, segment.prefix.slice(segment.start, segment.end)).then((result) => {
      let applied = false, unchanged = false, reason = result.validationError ? "Correction not applied: " + result.validationError : "Result discarded after an edit, selection change, blur, or composition.";
      if (this.active() && !result.validationError && queued.epoch === this.epoch && !this.composing && this.editor.isFocused()) {
        const selection = { start: this.editor.selectionStart, end: this.editor.selectionEnd, direction: this.editor.selectionDirection };
        const plan = planReplacement(segment, result.corrected, this.editor.value, selection);
        if (plan) {
          if (this.options.rolling && !queued.manual && !this.draft.canApply(segment, result.corrected)) {
            reason = "Suggestion would overwrite a word you edited or undid; not applied. Manual correction can explicitly revisit it.";
          } else if (this.editor.value.slice(segment.start, segment.end) === result.corrected) {
            unchanged = true;
            reason = "The model returned the text unchanged. It may not have decoded it; the next completed words will be included in another attempt.";
          } else {
            const beforeValue = this.editor.value, expectedValue = beforeValue.slice(0, plan.start) + plan.text + beforeValue.slice(plan.end);
            const scrollTop = this.editor.scrollTop, scrollLeft = this.editor.scrollLeft;
            this.applying = true;
            try {
              this.editor.setSelectionRange(plan.start, plan.end);
              applied = this.editor.insertText(plan.text);
              if (applied && this.editor.value !== expectedValue) {
                applied = false;
                this.invalidate("Host editor did not retain the requested text.");
                this.draft.protect(this.editor.value.length);
                reason = "Host editor did not retain the requested text; suggestion not confirmed.";
              } else if (applied) {
                this.editor.setSelectionRange(plan.selection.start, plan.selection.end, plan.selection.direction);
                reason = "Model suggestion applied; correctness is unverified. Undo restores the previous text.";
              } else {
                this.editor.setSelectionRange(selection.start, selection.end, selection.direction);
                reason = "Browser rejected native insertion; original text preserved.";
              }
            } finally {
              this.applying = false;
              this.previous = this.editor.value;
              this.editor.scrollTop = scrollTop;
              this.editor.scrollLeft = scrollLeft;
            }
          }
          if (applied) {
            if (this.options.rolling) this.draft.applied(segment, plan.text, queued.manual);
            this.frontier = plan.start + plan.text.length;
            if (this.queued && this.queued.boundary >= plan.end) this.queued.boundary += plan.delta;
          }
        }
      }
      const completedEnd = segment.start + (applied ? result.corrected.length : segment.end - segment.start);
      const unprocessedTail = (applied || unchanged) && !!this.editor.value.slice(completedEnd, this.editor.selectionStart).trim();
      this.options.status(reason);
      this.options.result({ segment, result, applied, unchanged, reason, unprocessedTail, elapsedMs: performance.now() - started });
    }).catch((e) => this.options.status("Correction failed; original text preserved. " + String(e))).finally(() => {
      this.pending = false;
      this.drain();
      this.options.changed?.();
    });
  }
};

// src/brii/cloud-client.ts
var CloudDecoder = class {
  constructor(send2) {
    this.send = send2;
  }
  current;
  async decode(text, context, current = text) {
    const requestId = crypto.randomUUID();
    this.current = requestId;
    const start = performance.now();
    try {
      const data = await this.send({ kind: "decode", requestId, text, context, current });
      if (data.error) throw Error(data.error);
      if (data.strategy !== "raw-only-baseline") throw Error("Restart the updated Brii bridge: this server is using a different decoding strategy.");
      if (typeof data.corrected !== "string" || !data.corrected.trim() || data.corrected.length > 1800) throw Error("Invalid cloud correction; original text was preserved.");
      return { strategy: data.strategy, model: typeof data.model === "string" ? data.model : void 0, corrected: data.corrected, rawOutput: data.corrected, ttftMs: null, totalMs: performance.now() - start, finishReason: "complete" };
    } finally {
      if (this.current === requestId) this.current = void 0;
    }
  }
  cancel() {
    if (this.current) void this.send({ kind: "cancel", requestId: this.current }).catch(() => {
    });
  }
};
var extensionTransport = (message) => chrome.runtime.sendMessage({ target: "briiCloud", ...message });

// src/brii/trigger.ts
var commandTriggers = [";;", "//", "--", "\\\\"];
function selectedTrigger(value) {
  return commandTriggers.includes(value) ? value : ";;";
}

// src/brii/cloud.ts
var cloudDefaults = { commandTrigger: ";;", enabled: false, automatic: true, sites: [], delay: 80 };
var cloudSettings = async () => {
  const stored = (await chrome.storage.local.get("briiCloud")).briiCloud;
  return { ...cloudDefaults, ...stored, commandTrigger: selectedTrigger(stored?.commandTrigger) };
};

// src/cloud-playground.ts
var $ = (id) => document.getElementById(id);
var consent = $("consent");
var auto = $("auto");
var correct = $("correct");
var extension = location.protocol === "chrome-extension:";
var configured = false;
var extensionId = "";
var localAbort;
var send = extension ? extensionTransport : async (message) => {
  if (message.kind === "cancel") {
    localAbort?.abort();
    return { ok: true };
  }
  const path = message.kind === "health" ? "/health" : "/correct";
  localAbort = new AbortController();
  const response = await fetch(path, { method: message.kind === "health" ? "GET" : "POST", headers: { "Content-Type": "application/json", "X-Brii-Extension": extensionId }, ...message.kind === "decode" ? { body: JSON.stringify({ text: message.text, context: message.context, current: message.current }) } : {}, signal: localAbort.signal, cache: "no-store" });
  const data = await response.json();
  return response.ok ? data : { error: data.error || "Bridge request failed." };
};
var last = resultView();
last.element.id = "lastResult";
$("status").after(last.element);
var decoder = new CloudDecoder(send);
var flow = new BriiFlow($("editor"), { rolling: true, active: () => consent.checked, ready: () => consent.checked && configured, automatic: () => auto.checked, delay: () => 80, decodingStatus: "Decoding with OpenAI\u2026 keep typing.", decode: (text, context, current) => decoder.decode(text, context, current), cancel: () => decoder.cancel(), status: (text) => {
  $("status").textContent = text;
}, result: (r) => {
  if (!consent.checked) {
    last.clear();
    return;
  }
  last.update(r);
  $("status").textContent = resultLabel(r) + (r.applied ? " \xB7 Undo to restore" : "");
} });
async function health() {
  try {
    const h = await send({ kind: "health" });
    const compatible = h.strategy === "raw-only-baseline";
    configured = !!h.enabled && !h.error && compatible;
    extensionId = h.extensionId || "";
    $("bridgeStatus").textContent = h.error || (!compatible ? "Bridge is outdated. Stop it with Ctrl+C and restart npm run cloud." : configured ? `Ready \xB7 ${h.model} \xB7 cloud` : "Set OPENAI_API_KEY in the bridge terminal and restart it.");
  } catch {
    $("bridgeStatus").textContent = "Start npm run cloud on this machine.";
  }
  correct.disabled = !configured || !consent.checked;
}
if (extension) void cloudSettings().then((s) => {
  consent.checked = s.enabled;
  auto.checked = s.automatic;
  void health();
});
else void health();
consent.onchange = async () => {
  if (!consent.checked) last.clear();
  if (extension) {
    const s = await cloudSettings();
    s.enabled = consent.checked;
    await chrome.storage.local.set({ briiCloud: s });
  }
  flow.invalidate(consent.checked ? "Cloud correction enabled. Type and press Space." : "Cloud correction off. No new text will be sent.");
  await health();
};
auto.onchange = () => flow.invalidate(auto.checked ? "Space correction enabled." : "Manual correction only.");
correct.onmousedown = (e) => e.preventDefault();
correct.onclick = () => flow.manual();
if (extension) chrome.storage.onChanged.addListener((c, a) => {
  if (a === "local" && c.briiCloud) {
    consent.checked = !!c.briiCloud.newValue?.enabled;
    if (!consent.checked) last.clear();
    flow.invalidate("Cloud settings changed.");
    correct.disabled = !configured || !consent.checked;
  }
});
window.addEventListener("pagehide", () => decoder.cancel());
