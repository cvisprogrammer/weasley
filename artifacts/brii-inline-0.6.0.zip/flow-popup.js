// src/brii/cloud.ts
var cloudDefaults = { enabled: false, automatic: true, sites: [], delay: 80 };
var cloudSettings = async () => ({ ...cloudDefaults, ...(await chrome.storage.local.get("briiCloud")).briiCloud || {} });

// src/shared.ts
function matchPattern(origin) {
  const u = new URL(origin);
  return `${u.protocol}//${u.hostname}/*`;
}

// src/brii/cloud-client.ts
var extensionTransport = (message) => chrome.runtime.sendMessage({ target: "briiCloud", ...message });

// src/flow-popup.ts
var $ = (id) => document.getElementById(id);
var input = (id) => $(id);
var s = await cloudSettings();
input("enabled").checked = s.enabled;
var save = async () => {
  await chrome.storage.local.set({ briiCloud: s });
};
async function activeWebsite() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const parse = (value) => {
    try {
      const url2 = new URL(value || "");
      return ["http:", "https:"].includes(url2.protocol) ? url2 : void 0;
    } catch {
      return void 0;
    }
  };
  let url = parse(tab?.url) || parse(tab?.pendingUrl);
  if (!url && tab?.id !== void 0) try {
    const [result] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: () => location.href });
    url = parse(result?.result);
  } catch {
  }
  if (!url || tab?.id === void 0) throw Error("Cannot access this website. Open its page, then click the Brii toolbar icon and try Allow this website again. Chrome internal pages are not supported.");
  return { tab, url };
}
async function injectActive() {
  try {
    const { tab, url } = await activeWebsite();
    if (s.enabled && s.sites.includes(url.origin)) await chrome.scripting.executeScript({ target: { tabId: tab.id, allFrames: true }, files: ["flow-content.js"] });
  } catch (e) {
    $("status").textContent = String(e);
  }
}
input("enabled").onchange = async () => {
  s.enabled = input("enabled").checked;
  await save();
  if (s.enabled) await injectActive();
};
function render() {
  $("sites").replaceChildren();
  for (const origin of s.sites) {
    const li = document.createElement("li");
    li.textContent = origin + " ";
    const remove = document.createElement("button");
    remove.textContent = "Remove";
    remove.onclick = async () => {
      s.sites = s.sites.filter((x) => x !== origin);
      await save();
      if (!s.sites.some((x) => matchPattern(x) === matchPattern(origin))) await chrome.permissions.remove({ origins: [matchPattern(origin)] });
      render();
    };
    li.append(remove);
    $("sites").append(li);
  }
}
render();
$("allow").onclick = async () => {
  try {
    const { tab, url } = await activeWebsite();
    if (await chrome.permissions.request({ origins: [matchPattern(url.origin)] })) {
      s.sites = [.../* @__PURE__ */ new Set([...s.sites, url.origin])];
      await save();
      if (tab.id && s.enabled) await chrome.scripting.executeScript({ target: { tabId: tab.id, allFrames: true }, files: ["flow-content.js"] });
      render();
      $("status").textContent = s.enabled ? "Website allowed. Type in an text field using //instruction//." : "Website allowed. Enable cloud commands when ready.";
    }
  } catch (e) {
    $("status").textContent = String(e);
  }
};
$("try").onclick = () => void chrome.tabs.create({ url: chrome.runtime.getURL("inline-playground.html") });
async function health() {
  try {
    const h = await extensionTransport({ kind: "health" });
    $("status").textContent = h.error || (h.commands !== true ? "Bridge is outdated. Stop it with Ctrl+C and restart npm run cloud." : !h.enabled ? "Bridge is running; set OPENAI_API_KEY and restart it." : `Bridge ready \xB7 ${h.model} \xB7 cloud commands ${s.enabled ? "enabled" : "off"}`);
  } catch {
    $("status").textContent = "Bridge not running. Start npm run cloud in your terminal.";
  }
}
void health();
